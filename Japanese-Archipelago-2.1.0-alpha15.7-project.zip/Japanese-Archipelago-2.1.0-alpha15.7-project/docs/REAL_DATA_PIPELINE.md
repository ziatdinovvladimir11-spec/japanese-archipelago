# Real Japan data pipeline (offline)

The project is being prepared so the eventual runtime JAR can work **without an Internet connection**. External geographic sources are used only during development/preprocessing.

## Source policy

The intended primary elevation source is the Geospatial Information Authority of Japan (GSI) Fundamental Geospatial Data Digital Elevation Model. GSI currently provides 1 m, 5 m and 10 m DEM products; the service notes that 1 m data is based on airborne laser surveying and that the products are distributed as GML. GSI also publishes elevation tiles derived from the DEM. Before redistributing processed data, check the current GSI content terms and any Surveying Act approval requirements that apply to Fundamental Geospatial Data.

References:

- https://service.gsi.go.jp/kiban/
- https://service.gsi.go.jp/kiban/app/help/
- https://web2.gsi.go.jp/kikakuchousei/kikakuchousei40182.html

## Pipeline

```text
local GSI/other licensed DEM
        |
        v
offline conversion
        |
        +--> elevation
        +--> slope
        +--> curvature
        +--> metadata
        |
        v
JPDM1 compressed binary
        |
        v
future Japanese Archipelago runtime reader
```

No runtime HTTP requests are part of this design.

## Recommended working resolution

For the first country-scale prototype, use a **200 m grid**. It is small enough for a fast runtime lookup but preserves the macro geography of Japan. A 100 m grid can be used for more detail at a larger data cost. Finer data can be used offline as an analysis source and downsampled before packaging.

## Why we keep derivatives

The DEM is not only a heightmap. The preprocessing stage also computes:

- slope — useful for distinguishing plains, foothills and mountain faces;
- curvature — useful for ridge/valley classification;
- later: flow direction / accumulation, watershed labels and coast/shelf masks.

These derivative layers are what let the generator use real Japanese geomorphology instead of simply copying a grayscale image into Y coordinates.

## First converter test

Create a small local GeoTIFF or NumPy grid, then run:

```powershell
python tools\\jp_data_pipeline.py input.tif build\\jpdata\\japan.jpdm.gz --cell 200 --metadata build\\jpdata\\japan.json
```

For an already metric NumPy grid:

```powershell
python tools\\jp_data_pipeline.py input.npy build\\jpdata\\sample.jpdm.gz --cell 200
```

The converter does not download anything.

## GSI GML note

GSI's downloadable DEM is commonly provided in GML. The current converter deliberately refuses to guess georeferencing from an unfamiliar GML schema. Convert the local GML files to GeoTIFF with a local GIS/GSI viewer/tool first, then feed the GeoTIFF to the converter. This avoids silently producing a correctly shaped but geographically wrong map when a GSI schema version changes.

## Distribution rule

Do not put raw GSI/GSJ source tiles into the Git repository or release archive until the exact source terms have been checked for the specific dataset/version. Prefer distributing the preprocessing tool and a documented recipe; if a derived runtime dataset is later bundled, include the required source/processing attribution and keep a record of which source versions produced it.
