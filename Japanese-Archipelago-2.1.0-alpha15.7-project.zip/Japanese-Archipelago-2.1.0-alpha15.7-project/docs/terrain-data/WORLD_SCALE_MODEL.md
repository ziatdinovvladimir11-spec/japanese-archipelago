# World scale model

Japanese Archipelago separates **source-data resolution** from **gameplay world scale**.

- DEM1A/DEM5A/DEM10B describe the source quality.
- JPDM is the runtime representation at the current 50 m game cell.
- The world-creation `World scale` setting controls how many real-world meters are represented by one Minecraft block relative to the 1.00x reference.
- `1.00x` uses the reference 7.6 m/block established by the current Fuji calibration.
- Higher scale values make the represented geographic area larger per Minecraft block; lower values make it smaller.
- Maximum terrain height remains an explicit, independent target for the output range.

This keeps data fidelity and gameplay scale independent, matching the architecture used by large real-world terrain importers such as Arnis.
