# Fuji runtime test

This prototype is the first point where real terrain data enters Minecraft world generation.

## Scaling model

The current dataset is a `339 x 339` JPDM grid at `50 m` cells, so its footprint is about `16.95 km x 16.95 km`.

The national terrain model uses an independent horizontal scale, while volcanic prototypes can use an isotropic local scale. Fuji uses an isotropic transform derived from its source elevation span and requested Minecraft Y span.

For Fuji:

- source peak: `3776 m`
- base Y: `63`
- peak Y: `560`
- effective horizontal scale: `7.597586 source m / Minecraft block`
- vertical scale: `0.131622 Minecraft blocks / source m`

For the current processed Fuji dataset, the source range is approximately `504.22 .. 3768.37 m`. This keeps the volcano close to an isotropic source-to-Minecraft scale instead of making it a tall, narrow cone.

## Runtime path

The development build copies:

`input/jpdata/fuji/fuji_dem5a_r8_50m.jpdm.gz`

to the mod resources automatically during `processResources`.

Minecraft runtime performs no HTTP access. The custom `japanese_archipelago:jpdm_height` density function loads the bundled JPDM once and bilinearly samples height. Outside the local Fuji rectangle it falls back to a flat Y=63 terrain height so the prototype remains playable.

## Test

1. Build the mod after the Fuji JPDM exists in `input/jpdata/fuji/`.
2. Enable the `Japanese Archipelago — Fuji` world preset.
3. Enter the world and go to approximately `X=0, Z=0`.
4. Check that Fuji rises from the center of the local test region and reaches roughly `Y=560`.

This is an acceptance prototype, not yet the final national Japan dataset. Slope, curvature, drainage, valley carving, coast distance and geology layers will be integrated after the height-only path is validated.


### Alpha5 calibration
The Fuji test now uses an absolute elevation remap: 0 m -> Y=63 and 3776 m -> Y=560. The local DEM minimum is no longer stretched to sea level. Horizontal scale remains 50 m per block.
