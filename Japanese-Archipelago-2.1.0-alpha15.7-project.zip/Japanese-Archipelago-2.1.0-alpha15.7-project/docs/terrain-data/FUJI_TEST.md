# Fuji test region

The first real-data prototype uses a small Fuji-area window rather than the whole of Japan.

**Prototype bbox:** `138.68,35.28,138.80,35.40` (west,south,east,north)

**Source:** GSI DEM5A PNG, zoom 15.

This window is intentionally local. The current JPDM1 metric frame uses a local origin; nationwide production will use a proper Japanese projected coordinate reference system instead of treating longitude/latitude as a flat plane.

The first acceptance test is:

- preserve Fuji's broad base and cone profile;
- preserve surrounding relief and valley placement;
- maintain smooth interpolation;
- map the real peak into the planned Minecraft vertical range (~Y=560) without independently distorting its footprint;
- keep the generated data small enough for fast runtime sampling.
