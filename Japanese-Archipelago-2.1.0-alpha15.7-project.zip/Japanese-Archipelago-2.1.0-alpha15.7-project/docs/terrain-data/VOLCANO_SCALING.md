# Volcano scaling model

Volcanoes use a local isotropic scale so their horizontal and vertical source-to-Minecraft coefficients are approximately equal. For a source elevation span `E` and Minecraft Y span `H`, the effective horizontal scale is `E / H` source metres per Minecraft block.

For Fuji: source peak 3776 m, base Y 63, peak Y 560 => 7.597586 m/block horizontally and 0.131622 blocks/m vertically. This makes the Fuji cone much broader than the earlier 50 m/block prototype while preserving its real DEM shape.

The JPDM grid remains sampled at 50 m, so isotropic runtime scaling is interpolation/upsampling of the processed DEM, not creation of new source detail.
