# Real Japan build plan

- DEM10B: nationwide base terrain and coast context.
- DEM5A: major mountain systems, important river valleys, volcano surroundings and Sengoku-critical areas.
- DEM1A: narrow local super-detail overrides, starting with Fuji.
- Final runtime grid: 50 m JPDM.
- World settings later control gameplay scale independently of source DEM resolution.
- Blend zone boundaries and validate coast/river continuity before nationwide packaging.
