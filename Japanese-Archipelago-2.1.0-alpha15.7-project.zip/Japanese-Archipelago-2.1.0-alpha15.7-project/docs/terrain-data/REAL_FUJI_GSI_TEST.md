# Real Fuji GSI test

This test replaces the synthetic cone with official GSI **DEM1A** tiles.

- Source: GSI DEM1A PNG XYZ tiles
- Zoom used for this test: **15** (about 4–5 m pixels near Mt. Fuji)
- Coverage: 25×25 XYZ tiles around the Fuji center tile
- JPDM target grid: **50 m**
- Runtime remains offline; downloads happen only during preprocessing.

Why z15 rather than z17? The source is still DEM1A, but z15 is already much finer than the 50 m JPDM target. It keeps the first real-data test practical while retaining the summit/crater morphology needed for validation. The official GSI tile index lists DEM1A PNG at zoom 1–17.

Workflow:

    python tools\\download_real_fuji.py --radius 12
    python tools\\build_real_fuji.py --radius 12 --cell 50

The resulting `fuji_dem1a_...jpdm.gz` is a developer/test artifact. Review GSI terms before redistribution of derived data.
