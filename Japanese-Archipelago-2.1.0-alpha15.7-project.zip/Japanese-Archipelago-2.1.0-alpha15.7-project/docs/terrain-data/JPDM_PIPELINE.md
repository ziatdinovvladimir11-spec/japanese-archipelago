# JPDM pipeline

```text
GSI DEM tiles
    ↓
XYZ tile mosaic
    ↓
invalid/missing-cell handling
    ↓
local metric resampling
    ↓
height / slope / curvature
    ↓
JPDM1
    ↓
Java runtime sampler
```

JPDM1 is a **derived runtime format**, not a GIS interchange format.

The runtime reader uses bilinear height sampling and no network access. A bundled dataset is optional until the first real Fuji dataset has been reviewed and validated.

For the Fuji prototype, 150 m cells are used to test the macro-terrain concept. This is deliberately coarse compared with GSI DEM5A; the fine source data is used to measure and preserve macro shape rather than to copy every 5 m detail into Minecraft.
