# JPDM1 — Japanese Archipelago terrain data format

JPDM1 is the project's compact, derived terrain-data format. It is deliberately not a copy of a GSI distribution format.

The current payload stores a regular metric grid with:

- surface elevation in 0.25 m units (`i16`),
- slope in 0.01 degree units (`i16`),
- curvature in 0.001 units (`i16`).

The file is gzip-compressed. The header stores grid dimensions, cell size, origin, flags and a nodata sentinel.

Runtime rules:

1. No network access.
2. Data are read once and sampled with bilinear interpolation.
3. The Minecraft adapter owns vertical remapping and coordinate transforms.
4. The data engine remains independent of biome selection and renderer code.

For GSI source material, preserve the original download metadata and license notices outside the JPDM file. Only a derived product should be considered for redistribution, and the applicable GSI terms must be checked for the exact source dataset.
