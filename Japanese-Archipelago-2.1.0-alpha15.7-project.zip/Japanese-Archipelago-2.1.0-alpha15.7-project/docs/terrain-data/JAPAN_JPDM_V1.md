# Japan JPDM runtime v1

The national terrain dataset is stored as a sparse directory of JPDM1 chunks plus one JSON manifest.
This is the runtime layout introduced in 2.1.0-alpha14.3.

## Why chunking

A complete 50 m Japan raster is too large to keep as several Java `float[]` arrays for a single
worldgen instance. The runtime therefore keeps only a small LRU cache of chunk files.

Default chunk size:

- 256 × 256 samples
- 50 m/sample
- about 12.8 km × 12.8 km per chunk

Each chunk retains the JPDM1 elevation, slope and curvature layers. The manifest maps integer chunk
coordinates to runtime resource names.

## Coordinate model

The preprocessing pipeline uses a Japan-centred azimuthal-equidistant projected metric CRS. The
manifest stores both the projected grid origin and the projected coordinate that corresponds to
Minecraft world block `(0,0)`.

Minecraft X/Z are converted with the national horizontal scale (default 50 source metres/block).
Vertical relief is independently mapped using the Fuji reference:

`0 m → Y=63`, `3776 m → Y=560`.

## Land boundary

The Japan land mask is authoritative. Cells outside it are written as JPDM NoData. This prevents
source tiles containing neighbouring countries or surrounding water from becoming Minecraft land.

## Detail zones

A DEM5A dataset can be supplied as an optional higher-quality source for explicit detail polygons.
The builder replaces the base DEM10B samples only inside those polygons and only when a finite detail
sample exists.
