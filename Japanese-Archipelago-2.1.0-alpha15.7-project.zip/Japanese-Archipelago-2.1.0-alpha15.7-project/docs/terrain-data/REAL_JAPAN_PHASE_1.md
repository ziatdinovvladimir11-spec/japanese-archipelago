# Real Japan terrain — Phase 1

The purpose of this phase is to replace the procedural macro terrain with a compact representation derived from real Japanese elevation data.

## Data source hierarchy

1. Prefer GSI DEM1A where available for high-quality local calibration.
2. Use GSI DEM5A as the default high-resolution source where DEM1A is unavailable.
3. Use DEM10B as a nationwide fallback / continuity source.
4. Keep each source's provenance and release date in the preprocessing manifest.

GSI documents the mesh structure and confirms that DEM1A is a 1 m product from airborne laser survey results, DEM5A is a 5 m airborne-laser product, and DEM10B is a nationwide 10 m product based on 1:25,000 topographic-map contours and related elevation information. citeturn282150search1turn282150search4

## Target representation

The first production dataset should be resampled to roughly 100–200 m macro cells. That is not a loss of the source dataset; it is a deliberate game-world scale. The Minecraft adapter then performs a controlled vertical remap so that the highest selected landmark can reach the intended Y target while preserving local shape.

## Derived layers

Phase 1 should generate:

- elevation,
- slope,
- curvature,
- coast distance,
- broad land/sea mask.

Phase 2 will add watershed and river-network layers.

## Testing strategy

Start with a small region around Mount Fuji and adjacent valleys. Do not generate the whole country until the scale, interpolation, coast profile and vertical remap are visually validated.
