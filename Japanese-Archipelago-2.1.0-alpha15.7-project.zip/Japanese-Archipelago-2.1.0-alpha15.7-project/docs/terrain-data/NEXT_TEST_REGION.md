# Next real-data test region

Use a small region centered on Mount Fuji and its surrounding foothills/valleys.

Acceptance criteria:

- horizontal scale is fixed and documented;
- vertical remap places Fuji near Y=560 without changing its horizontal scale;
- bilinear interpolation produces a continuous surface;
- coast/shelf are represented where the test bbox reaches water;
- no online fetch is performed by Minecraft;
- the produced JPDM1 stores only derived/resampled values and a provenance manifest.

Do not create the full Japan dataset until this test passes.
