# Real Japan data tiers — alpha 15.3

The production data hierarchy is now explicit:

1. **Base: DEM10B** — nationwide terrain and coastal context.
2. **Detail: DEM5A** — deliberate zones for major mountain belts, important valleys, volcano surroundings and Sengoku-critical regions.
3. **Super-detail: DEM1A** — narrow high-value zones, starting with Fuji/summit morphology.

All three sources are resampled onto the current 50 m JPDM game grid in this alpha. This keeps the runtime manifest architecture stable while allowing higher-quality source measurements to win inside their designated zones.

The runtime remains offline: no HTTP requests happen in Minecraft.

Do not turn the starter GeoJSON into a final nationwide zone file without reviewing the actual intended coverage. The current polygons are planning examples to anchor the pipeline.

GSI currently publishes DEM1A, DEM5A, DEM5B/5C and DEM10B elevation tiles; DEM1A/DEM5A are derived from airborne laser surveying, while DEM10B is nationwide and based on 1:25,000 map contours. See the GSI source notes and current download terms before redistributing derived data.
