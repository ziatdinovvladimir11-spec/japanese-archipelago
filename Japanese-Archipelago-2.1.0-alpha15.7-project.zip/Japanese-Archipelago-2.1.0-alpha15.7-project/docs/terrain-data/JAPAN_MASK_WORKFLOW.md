# Non-rectangular Japan data workflow

The national Japan dataset should not be collected as one large square. Developer preprocessing starts from a Japan land/coast GeoJSON and adds only a limited coastal buffer for terrain continuity.

The workflow is:

1. Obtain a current Japan coastline/land geometry from an approved source; do not bundle it automatically.
2. Run `tools/japan_region.py` to select only GSI tiles intersecting that geometry plus the chosen coastal buffer.
3. Download only the manifest tiles with retry/audit.
4. Convert the DEM into a georeferenced JPDM dataset and clip/mask it by the Japan geometry.
5. Keep the neighbouring countries outside the land mask; the coastal buffer exists only to support underwater shelves and near-shore terrain.

GSI's current Fundamental Geospatial Data service documents `coastline`, administrative boundaries and DEM as national datasets, and the service was updated in 2026 with the JGD2024 reference system. See `docs/GSI_DOWNLOAD_NOTES.md` before acquiring final source data.
