# World scale model — alpha 15.7

The world scale is independent from source DEM resolution. At 1.00x, the reference horizontal density is 7.6 m per Minecraft block. The world scale changes X/Z sampling as 7.6 / scale and changes vertical relief with a square-root factor before mapping into the selected baseY..peakY range.

The maximum-height setting remains the target top of the rendered terrain; the sampler does not allow source values above the selected peak to create a hard clipped plateau. Source DEM1A/DEM5A/DEM10B remain independent of the gameplay scale.
