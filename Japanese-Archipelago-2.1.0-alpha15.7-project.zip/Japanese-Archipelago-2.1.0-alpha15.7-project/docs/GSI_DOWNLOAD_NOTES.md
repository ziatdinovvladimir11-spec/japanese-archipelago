# GSI elevation acquisition notes

GSI publishes national elevation tiles derived from its Fundamental Geospatial Data DEM. The current tile directory lists DEM1A, DEM5A, DEM5B, DEM5C and DEM10B PNG endpoints, and the official detailed specification defines the RGB-to-height encoding. The public tile service is useful for the **development/preprocessing** stage only.

Official references:

- Tile catalog: https://maps.gsi.go.jp/development/ichiran.html
- Elevation tile specification: https://maps.gsi.go.jp/development/demtile.html
- DEM service/help: https://service.gsi.go.jp/kiban/app/help/
- GSI terms: https://web2.gsi.go.jp/kikakuchousei/kikakuchousei40182.html

The downloader is `tools/gsi_tile_downloader.py`. It intentionally has no place in the Minecraft runtime.

Example development command:

```powershell
python tools\\gsi_tile_downloader.py --source dem5a --zoom 8 --bbox 122,24,146,46
```

For a first prototype, do **not** download the whole country at very high zoom. Start with a single island/region or a coarse zoom and verify the preprocessing pipeline first.

GSI's PNG height encoding is:

```text
x = 2^16 R + 2^8 G + B
x < 2^23  -> h = x * 0.01 m
x = 2^23  -> invalid
x > 2^23  -> h = (x - 2^24) * 0.01 m
invalid pixel: R=128,G=0,B=0
```

The runtime mod must never download these tiles.
