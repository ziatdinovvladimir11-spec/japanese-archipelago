# Optimization test profile — Fabric 1.21.1

Recommended for this project:

- Sodium 0.6.13 — client renderer optimization.
- Lithium 0.14.7 — game-logic optimization.
- FerriteCore 7.0.3 — memory optimization.
- ImmediatelyFast 1.6.10 — immediate-mode rendering optimization.
- Entity Culling 1.9.5 — client-side visibility culling.
- ModernFix 5.21.0 — performance/memory/bug fixes.
- C2ME 0.3.0+alpha.0.362 — chunk-management benchmarking; treat as an experimental profile.

Keep two profiles while developing:

1. **Correctness profile:** Japanese Archipelago + Fabric API + Lithostitched + Sodium only.
2. **Performance profile:** add Lithium, FerriteCore, ImmediatelyFast, Entity Culling, ModernFix and C2ME.

Voxy is deliberately not a project dependency. The official Modrinth Voxy 0.2.14-alpha page currently targets newer Minecraft/Sodium versions, so a 1.21.1 unofficial fork should be treated as a separate experimental client component.
