# Japanese geomorphology model

This project intentionally does **not** copy Tectonic or another terrain overhaul. Those projects are technical references. The terrain model is based on the structure observed in the Japanese archipelago.

## Planned layers

1. **Island/coast mask** — real coastline and a smoothed marine shelf.
2. **Structural belts** — broad mountain systems aligned with the island arc.
3. **Relief hierarchy** — coast → lowland → foothill → mountain mass → ridge → summit.
4. **Volcanic centers** — sparse cones/calderas superimposed on appropriate mountain/arc regions.
5. **Drainage** — watershed boundaries, tributaries, main valleys, alluvial fans and coastal plains.
6. **Climate** — initially vanilla multi-noise on top of the terrain, with dry/extreme-heat tails suppressed for the Japanese test environment.
7. **Biome/compatibility layer** — Lithostitched first; other terrain overhauls remain secondary.

## Runtime philosophy

The final Minecraft runtime should not fetch geographic data. A compact preprocessed dataset is loaded locally and sampled through a small number of cached fields. This keeps chunk generation predictable and lets Sengoku Jidai depend on stable Japanese geography rather than on another terrain overhaul's internals.
