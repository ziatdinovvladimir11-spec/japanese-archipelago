# Data redistribution checklist

Before bundling any processed Japan terrain dataset in a public release:

- Identify the exact GSI/GSJ source dataset and version/date.
- Save the source page URL and applicable terms with the preprocessing build.
- Confirm whether the use is merely analysis, edited publication, reproduction, or use of Fundamental Geospatial Survey results requiring an application.
- Keep source attribution and an explicit statement that the data was edited/processed.
- Do not imply that GSI/GSJ created the derived Minecraft dataset.
- Check third-party datasets separately; do not assume GSI terms cover GSJ or other providers.

The project therefore keeps source acquisition and preprocessing outside the runtime JAR until the redistribution status of the selected datasets is settled.
