# JPDM1 format

`JPDM1` is a gzip-compressed little-endian binary created by `tools/jp_data_pipeline.py`.

Header:

```text
6 bytes  magic: JPDM1\0
1 byte   version (1)
1 byte   flags (bit 0 height, bit 1 slope, bit 2 curvature)
4 bytes  width uint32
4 bytes  height uint32
4 bytes  cell size float32, meters
4 bytes  west float32, metric coordinate
4 bytes  south float32, metric coordinate
4 bytes  nodata float32
```

Payload layers, row-major:

- int16 height × 4 (0.25 m units)
- int16 slope × 100 (0.01 degrees)
- int16 curvature × 1000

The format is intentionally simple so a small Java reader can later memory-map/decompress it without pulling a GIS stack into Minecraft.
