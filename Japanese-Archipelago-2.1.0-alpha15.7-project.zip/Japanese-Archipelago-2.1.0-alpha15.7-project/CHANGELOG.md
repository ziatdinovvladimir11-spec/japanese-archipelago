# 2.1.0-alpha15.7

- Arnis-style world scale model.
- World scale affects X/Z sampling and vertical relief independently of source DEM resolution.
- Keeps max-height as the target terrain ceiling without source-data clipping.

# 2.1.0-alpha15.6

- Real Japan data tiering: DEM10B nationwide base, DEM5A detail zones, DEM1A local super-detail overrides.
- Keeps the runtime JPDM grid at 50 m.
- Separates source-data resolution from gameplay scale.

## 2.1.0-alpha15.1-fixed6
- Fixed Japanese Archipelago world-settings button activation.
- Uses a client-side injection into WorldCreator#getLevelScreenProvider and compares the actual WorldPreset registry key value to japanese_archipelago:japan_real.
- Removed the previous static-map and overwrite approaches.

# 2.1.0-alpha15.1

- Added native Japanese Archipelago world-creation settings screen for the real-data preset.
- Terrain controls expose horizontal scale, maximum height, and fine-relief preference.
- Selected terrain scale/height are applied at runtime to the JPDM Japan manifest sampler.
- Voxy integration remains optional and is not falsely exposed as implemented.

## 2.1.0-alpha15.0

- Fixed the fragile terrain-data build path: prepared Japan JPDM now lives under `input/jpdata/japan`, so `clean` no longer deletes it before resource bundling.
- Bundled an offline synthetic JPDM acceptance dataset (81 tiles) so `japan_real` exercises the manifest-backed height path instead of silently falling back to flat Y=63.
- Added `tools/make_offline_acceptance_jpdm.py` for deterministic offline pipeline validation.
- The bundled acceptance terrain is synthetic and is not a geographic representation of Japan; real GSI DEM data remains the production dataset.

## 2.1.0-alpha14.4

First real Japan DEM test-region pipeline. Added a deterministic developer-only tool that downloads a small official GSI DEM10B region around a configurable center, builds a VRT, clips it to the Japan land mask, generates chunked JPDM1, and places the resulting manifest under `input/jpdata/japan` for the `japan_real` preset. The default test region is the Fuji–Suruga corridor, chosen to exercise mountains, foothills, plains and coast without attempting a nationwide download. Added preview/metadata output and kept runtime network-free.

## 2.1.0-alpha14.2

Build-system fix: optional Fuji/Japan runtime datasets no longer register missing generated files as Gradle task inputs. The build can complete without pre-generated JPDM data; runtime bundling still occurs automatically when the datasets exist.

# Changelog


## 2.1.0-alpha14

- Standardized project version metadata on `2.1.0-alpha14`.
- Added a sparse, chunked Japan JPDM runtime manifest and bounded LRU tile cache.
- Added `japan_real` terrain density chain and opt-in world preset.
- Added offline `japan_jpdm_builder.py` for projected GeoTIFF/VRT → chunked JPDM1 generation with land-mask clipping and derivative halo.
- Added `gsi_xyz_vrt.py` to build a georeferenced VRT from downloaded GSI XYZ PNG tiles without loading the full country into memory.
- Added `gsi_manifest_downloader.py` for resumable manifest-driven source acquisition.
- Fixed detail-zone kilometre buffering to use a real metric projection instead of degree arithmetic.
- Expanded `.gitignore` to exclude Python caches and generated JPDM datasets.
- Kept Fuji isotropic scaling and renderer-agnostic Sodium/Voxy compatibility.

## 2.1.0-alpha13

- Added a pre-download Japan coverage/storage report.
- Added an optional DEM5A detail-zone planner for volcano/mountain/river/history zones.
- Kept the alpha12 Japan mask and irregular land+coast planner unchanged.
- Kept Fuji isotropic scaling and Voxy-compatible runtime unchanged.

## 2.1.0-alpha15.6
- Replace the raw horizontal meters/block setting in the world-creation menu with an Arnis-style World Scale control.
- Keep source DEM resolution independent from gameplay scale.
- Preserve the current 1.00x / 7.6 m-block reference calibration and the independent maximum-height setting.
