<div align="center">

<img src="docs/logo.png" alt="Japanese Archipelago" width="360">

# Japanese Archipelago 2.1.0-alpha14.4

**Real-data geomorphological terrain foundation for Minecraft Java 1.21.1 Fabric.**

Minecraft **1.21.1** · Fabric · Lithostitched · Sodium/Voxy compatible

</div>

## Purpose

Japanese Archipelago is a renderer-agnostic world-generation foundation intended for Sengoku Jidai. The terrain model is driven by real Japanese elevation and coastline data prepared offline; the Minecraft runtime performs local sampling only and does not access the network.

The project is an independent implementation. Tectonic, TerraBlender, Biomes O' Plenty, Terralith, Streams Reflowing and Arnis are engineering references rather than code dependencies.

## Terrain architecture

```text
GSI source data (developer machine only)
        ↓
Japan coastline / land mask
        ↓
GSI DEM10B nationwide coverage
        +
DEM5A detail zones (optional)
        ↓
projected metric grid
        ↓
chunked JPDM1 tiles + manifest
        ↓
Japanese Archipelago terrain engine
        ↓
Minecraft vanilla chunks
        ↓
Sodium → Voxy LOD (renderer remains untouched)
```

## Scale model

National terrain uses an independent horizontal scale of **50 source metres per Minecraft block**. Vertical relief is globally referenced to Fuji: **0 m → Y=63** and **3776 m → Y=560**. Volcanoes may additionally use local isotropic calibration so their horizontal and vertical scale coefficients remain approximately equal.

## Real Japan preset

The prepared real-data preset is `japanese_archipelago:japan_real`. It expects:

```text
input/jpdata/japan/manifest.json
```

The build copies that prepared dataset into runtime resources. The runtime manifest resolves only the JPDM chunk needed by the current world-generation position and keeps a small bounded tile cache, so the entire country is never loaded into memory at once.

Until the national dataset exists, the normal `japanese` preset remains the stable procedural baseline.

## Offline data pipeline

1. Generate or validate `japan_land_mask.geojson` from the GSI Global Map Japan vector package.
2. Plan DEM10B land + one-tile coastal-ring coverage with `japan_region.py`.
3. Estimate source and JPDM storage with `japan_coverage_report.py`.
4. Before any nationwide download, build the small deterministic Fuji–Suruga acceptance region with `japan_real_test_region.py`.
5. Download the exact manifest with `gsi_manifest_downloader.py`.
6. Create a georeferenced PNG VRT with `gsi_xyz_vrt.py`.
7. Build chunked JPDM with `japan_jpdm_builder.py`, clipping all non-Japan cells to NoData.
8. Optionally build DEM5A detail zones for volcanoes, mountain belts, valleys and historically important regions.
9. Run `./gradlew build` and test `japan_real`.

## First real Japan acceptance test

The recommended first national-engine acceptance test is a deliberately small DEM10B region around
35.00 N, 138.55 E (Fuji–Suruga corridor). It is large enough to exercise mountain slopes, foothills,
lowlands and a coastal transition, but small enough to download quickly. Run `python .\tools\japan_real_test_region.py`.
The script uses the same land mask, projected JPDM builder and runtime manifest as the future nationwide
dataset and places Minecraft world `(0,0)` at the test-region center.

## Fuji acceptance test

Fuji remains the regression landmark. The GSI-derived DEM5A prototype is mapped to `Y=63..560` with isotropic local scale. Any terrain-engine change should preserve Fuji proportions and keep Voxy working.

## Compatibility philosophy

The mod does not add renderer hooks or Voxy mixins. It produces ordinary Minecraft terrain/chunks; Sodium and Voxy remain downstream consumers. Sengoku Jidai can treat the mod as the geographic terrain foundation.

## Build

```powershell
.\gradlew.bat build
```

The distributable JAR is written to `build/libs/`.

## Licensing

Japanese Archipelago is distributed under the MIT License. Review the current GSI source terms before redistributing any generated terrain data. See `LICENSE`, `NOTICE.md`, `CREDITS.md` and `docs/DATA_LICENSE_CHECKLIST.md`.

## Alpha 15.1 — world creation settings

The `japan_real` world preset registers a native Minecraft world-settings screen through `LevelScreenProvider`. The screen exposes the terrain horizontal scale, maximum terrain height, and fine-relief preference. Selected values are applied to the Japan JPDM manifest sampler for the current world-creation session.

Voxy pre-generation is intentionally not exposed as a fake toggle yet; it will be implemented as an optional integration once the target Voxy API/backport is selected.

## Alpha 15.3 — real-data tiers

The real-data pipeline uses DEM10B nationwide, DEM5A in explicit detail zones, and DEM1A in narrow super-detail zones such as Fuji. See `docs/terrain-data/REAL_DATA_TIERS_ALPHA15.3.md` and `tools/build_real_japan.bat`.

## Real Fuji test (alpha 15.3)

Use `tools/build_real_fuji_test.bat` to download the official GSI DEM1A Fuji test area and preprocess it into JPDM1 at 50 m. This is the first real-data replacement for the synthetic Fuji acceptance cone.

## Alpha 15.4 — real Fuji DEM1A

The Fuji runtime preset now consumes `input/jpdata/fuji/fuji_dem1a_r12_50m.jpdm.gz` produced by the real GSI DEM1A importer.

## Alpha 15.6 — Arnis-style world scale

The world-creation menu now exposes `World scale` as the gameplay-scale control. The 1.00x reference corresponds to the current calibrated 7.6 m/block sampling. Lower values make the represented region smaller; higher values make it larger. Source DEM resolution remains independent from this setting.
