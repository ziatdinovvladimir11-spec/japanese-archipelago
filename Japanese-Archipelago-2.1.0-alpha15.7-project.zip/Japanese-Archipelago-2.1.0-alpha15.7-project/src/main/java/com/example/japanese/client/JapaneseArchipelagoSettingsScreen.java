package com.example.japanese.client;

import com.example.japanese.terrain.JPDMSettings;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.world.CreateWorldScreen;
import net.minecraft.client.world.GeneratorOptionsHolder;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Native world-creation settings for the Japanese Archipelago preset. */
public final class JapaneseArchipelagoSettingsScreen extends Screen {
    private final CreateWorldScreen parent;

    private static final double[] SCALE_VALUES = {0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0};
    private static final double[] PEAK_VALUES = {320.0, 400.0, 480.0, 560.0, 640.0};

    private int scaleIndex = 3;
    private int peakIndex = 3;
    private boolean fineRelief = true;

    public JapaneseArchipelagoSettingsScreen(CreateWorldScreen parent, GeneratorOptionsHolder generatorOptionsHolder) {
        super(Text.translatable("japanese_archipelago.settings.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 155;
        int right = this.width / 2 + 5;

        this.addDrawableChild(ButtonWidget.builder(scaleText(), button -> {
            scaleIndex = (scaleIndex + 1) % SCALE_VALUES.length;
            button.setMessage(scaleText());
        }).dimensions(left, 72, 310, 22).build());

        this.addDrawableChild(ButtonWidget.builder(peakText(), button -> {
            peakIndex = (peakIndex + 1) % PEAK_VALUES.length;
            button.setMessage(peakText());
        }).dimensions(left, 128, 310, 22).build());

        this.addDrawableChild(ButtonWidget.builder(fineReliefText(), button -> {
            fineRelief = !fineRelief;
            button.setMessage(fineReliefText());
        }).dimensions(left, 184, 310, 22).build());

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), button -> {
            JPDMSettings.apply(SCALE_VALUES[scaleIndex], 63.0, PEAK_VALUES[peakIndex], fineRelief);
            this.client.setScreen(parent);
        }).dimensions(left, 235, 150, 22).build());

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.cancel"), button ->
                this.client.setScreen(parent)
        ).dimensions(right, 235, 150, 22).build());
    }

    private Text scaleText() {
        double scale = SCALE_VALUES[scaleIndex];
        return Text.translatable("japanese_archipelago.settings.scale", scale);
    }

    private Text peakText() {
        return Text.translatable("japanese_archipelago.settings.peak", PEAK_VALUES[peakIndex]);
    }

    private Text fineReliefText() {
        return Text.translatable("japanese_archipelago.settings.fine_relief", fineRelief ?
                Text.translatable("options.on") : Text.translatable("options.off"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 28, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.translatable("japanese_archipelago.settings.subtitle"), this.width / 2, 45, 0xA0A0A0);
        context.drawTextWithShadow(this.textRenderer,
                Text.translatable("japanese_archipelago.settings.sea_level"), this.width / 2 - 155, 109, 0xFFFFFF);
        context.drawTextWithShadow(this.textRenderer,
                Text.translatable("japanese_archipelago.settings.scale_help"), this.width / 2 - 155, 96, 0xA0A0A0);
        context.drawTextWithShadow(this.textRenderer,
                Text.translatable("japanese_archipelago.settings.voxy_note"), this.width / 2 - 155, 207, 0x808080);
        super.render(context, mouseX, mouseY, delta);
    }
}
