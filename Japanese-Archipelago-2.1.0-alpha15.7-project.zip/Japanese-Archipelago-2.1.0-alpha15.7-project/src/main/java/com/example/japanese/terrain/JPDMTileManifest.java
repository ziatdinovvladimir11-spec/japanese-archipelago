package com.example.japanese.terrain;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Runtime index for a sparse, chunked Japan JPDM dataset.
 *
 * <p>The manifest is deliberately tiny compared with the terrain rasters. It maps
 * a regular projected-metric grid to JPDM tile resources so the runtime can load
 * only the tile(s) needed by the currently generated chunks.</p>
 */
public final class JPDMTileManifest {
    private static final Gson GSON = new Gson();

    private final double cellMeters;
    private final int chunkCells;
    private final double gridOriginX;
    private final double gridOriginZ;
    private final double worldOriginX;
    private final double worldOriginZ;
    private final Map<Long, String> resources;

    private JPDMTileManifest(double cellMeters, int chunkCells,
                             double gridOriginX, double gridOriginZ,
                             double worldOriginX, double worldOriginZ,
                             Map<Long, String> resources) {
        this.cellMeters = cellMeters;
        this.chunkCells = chunkCells;
        this.gridOriginX = gridOriginX;
        this.gridOriginZ = gridOriginZ;
        this.worldOriginX = worldOriginX;
        this.worldOriginZ = worldOriginZ;
        this.resources = Map.copyOf(resources);
    }

    public static JPDMTileManifest load(InputStream input) throws IOException {
        try (Reader reader = new InputStreamReader(input, StandardCharsets.UTF_8)) {
            Root root = GSON.fromJson(reader, Root.class);
            if (root == null || root.format == null || !root.format.startsWith("JapanJPDMManifest-v1")) {
                throw new IOException("Unsupported or invalid Japan JPDM manifest");
            }
            if (!(root.cell_m > 0.0) || root.chunk_cells <= 0) {
                throw new IOException("Invalid Japan JPDM manifest grid");
            }

            Map<Long, String> entries = new HashMap<>();
            if (root.tiles != null) {
                for (Tile tile : root.tiles) {
                    if (tile == null || tile.resource == null || tile.resource.isBlank()) {
                        continue;
                    }
                    entries.put(pack(tile.ix, tile.iz), tile.resource);
                }
            }
            if (entries.isEmpty()) {
                throw new IOException("Japan JPDM manifest contains no tiles");
            }
            return new JPDMTileManifest(
                    root.cell_m,
                    root.chunk_cells,
                    root.grid_origin_x_m,
                    root.grid_origin_z_m,
                    root.world_origin_x_m,
                    root.world_origin_z_m,
                    entries
            );
        } catch (JsonParseException | NumberFormatException ex) {
            throw new IOException("Invalid Japan JPDM manifest JSON", ex);
        }
    }

    public String resourceAt(double xMeters, double zMeters) {
        double span = cellMeters * chunkCells;
        int ix = floorDivToInt((xMeters - gridOriginX) / span);
        int iz = floorDivToInt((zMeters - gridOriginZ) / span);
        return resources.get(pack(ix, iz));
    }

    public double worldOriginX() { return worldOriginX; }
    public double worldOriginZ() { return worldOriginZ; }
    public double cellMeters() { return cellMeters; }
    public int chunkCells() { return chunkCells; }

    private static int floorDivToInt(double value) {
        if (value <= Integer.MIN_VALUE) return Integer.MIN_VALUE;
        if (value >= Integer.MAX_VALUE) return Integer.MAX_VALUE;
        return (int) Math.floor(value);
    }

    private static long pack(int ix, int iz) {
        return ((long) ix << 32) ^ (iz & 0xffffffffL);
    }

    private static final class Root {
        String format;
        double cell_m;
        int chunk_cells;
        double grid_origin_x_m;
        double grid_origin_z_m;
        double world_origin_x_m;
        double world_origin_z_m;
        Tile[] tiles;
    }

    private static final class Tile {
        int ix;
        int iz;
        String resource;
    }
}
