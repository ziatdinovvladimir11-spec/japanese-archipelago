package com.example.japanese.terrain;

import com.example.japanese.JapaneseArchipelagoMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/** Registration for custom density-function types used by the real-data adapter. */
public final class JapaneseDensityFunctions {
    public static final Identifier JPDM_HEIGHT =
            Identifier.of(JapaneseArchipelagoMod.MOD_ID, "jpdm_height");

    private JapaneseDensityFunctions() {}

    public static void init() {
        Registry.register(
                Registries.DENSITY_FUNCTION_TYPE,
                JPDM_HEIGHT,
                JPDMHeightDensityFunction.CODEC
        );

        JapaneseArchipelagoMod.LOGGER.info(
                "Registered JPDM density function type: {}",
                JPDM_HEIGHT
        );
    }
}
