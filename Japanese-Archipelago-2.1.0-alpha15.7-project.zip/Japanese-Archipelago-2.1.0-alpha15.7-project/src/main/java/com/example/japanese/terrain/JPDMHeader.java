package com.example.japanese.terrain;

import java.io.DataInputStream;
import java.io.IOException;

/** Header for the offline JPDM1 terrain format. Little-endian on disk. */
public record JPDMHeader(
        int version,
        int flags,
        int width,
        int height,
        float cellMeters,
        float westMeters,
        float southMeters,
        float nodata
) {
    public static final byte[] MAGIC = new byte[]{'J', 'P', 'D', 'M', '1', 0};

    public static JPDMHeader read(DataInputStream in) throws IOException {
        byte[] magic = in.readNBytes(6);
        if (!java.util.Arrays.equals(magic, MAGIC)) {
            throw new IOException("Invalid JPDM1 magic");
        }
        int version = in.readUnsignedByte();
        int flags = in.readUnsignedByte();
        int width = readLEInt(in);
        int height = readLEInt(in);
        float cell = readLEFloat(in);
        float west = readLEFloat(in);
        float south = readLEFloat(in);
        float nodata = readLEFloat(in);
        if (width <= 0 || height <= 0 || cell <= 0) {
            throw new IOException("Invalid JPDM1 dimensions");
        }
        return new JPDMHeader(version, flags, width, height, cell, west, south, nodata);
    }

    static int readLEInt(DataInputStream in) throws IOException {
        int b0 = in.readUnsignedByte();
        int b1 = in.readUnsignedByte();
        int b2 = in.readUnsignedByte();
        int b3 = in.readUnsignedByte();
        return b0 | (b1 << 8) | (b2 << 16) | (b3 << 24);
    }

    static float readLEFloat(DataInputStream in) throws IOException {
        return Float.intBitsToFloat(readLEInt(in));
    }
}
