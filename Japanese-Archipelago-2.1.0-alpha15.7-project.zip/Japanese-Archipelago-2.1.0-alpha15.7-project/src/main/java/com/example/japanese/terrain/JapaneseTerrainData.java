package com.example.japanese.terrain;

import com.example.japanese.JapaneseArchipelagoMod;

import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/** Runtime JPDM resource cache. No network access is performed. */
public final class JapaneseTerrainData {
    private static final String ROOT = "/data/japanese_archipelago/terrain/";
    private static final int MAX_TILE_CACHE = 12;

    private static final Map<String, Optional<JPDM1>> DIRECT_CACHE = new ConcurrentHashMap<>();
    private static final Map<String, Optional<JPDMTileManifest>> MANIFEST_CACHE = new ConcurrentHashMap<>();
    private static final Map<String, JPDM1> TILE_CACHE = new LinkedHashMap<>(16, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, JPDM1> eldest) {
            return size() > MAX_TILE_CACHE;
        }
    };

    private JapaneseTerrainData() {}

    public static Optional<JPDM1> loadBundled(String resourceName) {
        String normalized = normalize(resourceName);
        return DIRECT_CACHE.computeIfAbsent(normalized, JapaneseTerrainData::loadInternal);
    }

    public static Optional<JPDMTileManifest> loadManifest(String resourceName) {
        String normalized = normalize(resourceName);
        return MANIFEST_CACHE.computeIfAbsent(normalized, JapaneseTerrainData::loadManifestInternal);
    }

    /** Sample a single-value JPDM or a manifest-backed sparse dataset. */
    public static float sampleHeightMeters(String resourceName, double xMeters, double zMeters) {
        String normalized = normalize(resourceName);
        if (normalized.endsWith(".json")) {
            JPDMTileManifest manifest = loadManifest(normalized).orElse(null);
            if (manifest == null) return Float.NaN;
            String tileResource = manifest.resourceAt(xMeters, zMeters);
            if (tileResource == null) return Float.NaN;
            JPDM1 tile = loadTileFromManifest(tileResource);
            return tile == null ? Float.NaN : tile.sampleHeightMeters(xMeters, zMeters);
        }
        JPDM1 data = loadBundled(normalized).orElse(null);
        return data == null ? Float.NaN : data.sampleHeightMeters(xMeters, zMeters);
    }

    private static JPDM1 loadTileFromManifest(String tileResource) {
        String normalized = normalize(tileResource);
        synchronized (TILE_CACHE) {
            JPDM1 cached = TILE_CACHE.get(normalized);
            if (cached != null) return cached;
        }
        Optional<JPDM1> loaded = loadInternal(normalized);
        if (loaded.isEmpty()) return null;
        synchronized (TILE_CACHE) {
            TILE_CACHE.put(normalized, loaded.get());
            return loaded.get();
        }
    }

    private static Optional<JPDM1> loadInternal(String resourceName) {
        String resource = ROOT + resourceName;
        try (InputStream in = JapaneseTerrainData.class.getResourceAsStream(resource)) {
            if (in == null) {
                JapaneseArchipelagoMod.LOGGER.warn("JPDM resource not bundled: {}", resource);
                return Optional.empty();
            }
            JPDM1 loaded = JPDM1.load(in);
            JapaneseArchipelagoMod.LOGGER.info(
                    "Loaded JPDM1 terrain data: {} ({}x{}, {}m cells)",
                    resourceName, loaded.header().width(), loaded.header().height(), loaded.header().cellMeters()
            );
            return Optional.of(loaded);
        } catch (IOException | RuntimeException ex) {
            JapaneseArchipelagoMod.LOGGER.error("Failed to load JPDM resource: " + resourceName, ex);
            return Optional.empty();
        }
    }

    private static Optional<JPDMTileManifest> loadManifestInternal(String resourceName) {
        String resource = ROOT + resourceName;
        try (InputStream in = JapaneseTerrainData.class.getResourceAsStream(resource)) {
            if (in == null) {
                JapaneseArchipelagoMod.LOGGER.warn("Japan JPDM manifest not bundled: {}", resource);
                return Optional.empty();
            }
            JPDMTileManifest loaded = JPDMTileManifest.load(in);
            JapaneseArchipelagoMod.LOGGER.info(
                    "Loaded Japan JPDM manifest: {} ({}m cells, {}-cell chunks)",
                    resourceName, loaded.cellMeters(), loaded.chunkCells()
            );
            return Optional.of(loaded);
        } catch (IOException | RuntimeException ex) {
            JapaneseArchipelagoMod.LOGGER.error("Failed to load Japan JPDM manifest: " + resourceName, ex);
            return Optional.empty();
        }
    }

    private static String normalize(String resourceName) {
        String value = resourceName == null ? "" : resourceName.trim().replace('\\', '/');
        while (value.startsWith("/")) value = value.substring(1);
        return value;
    }
}
