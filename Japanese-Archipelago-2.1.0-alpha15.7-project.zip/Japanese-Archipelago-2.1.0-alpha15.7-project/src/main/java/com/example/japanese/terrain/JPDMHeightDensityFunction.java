package com.example.japanese.terrain;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.dynamic.CodecHolder;
import net.minecraft.world.gen.densityfunction.DensityFunction;

/**
 * Y-independent terrain-height function backed by a bundled JPDM1 raster or a
 * sparse Japan JPDM manifest. No renderer integration is performed.
 */
public record JPDMHeightDensityFunction(
        String resource,
        double metersPerBlock,
        double sourceBaseMeters,
        double sourcePeakMeters,
        double baseY,
        double peakY,
        boolean isotropicHorizontalScale,
        String coordinateMode,
        double worldOriginXMeters,
        double worldOriginZMeters
) implements DensityFunction.Base {
    public static final MapCodec<JPDMHeightDensityFunction> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Codec.STRING.optionalFieldOf("resource", "fuji_dem1a_r12_50m.jpdm.gz")
                    .forGetter(JPDMHeightDensityFunction::resource),
            Codec.DOUBLE.optionalFieldOf("meters_per_block", 50.0)
                    .forGetter(JPDMHeightDensityFunction::metersPerBlock),
            Codec.DOUBLE.optionalFieldOf("source_base_m", 0.0)
                    .forGetter(JPDMHeightDensityFunction::sourceBaseMeters),
            Codec.DOUBLE.optionalFieldOf("source_peak_m", 3776.0)
                    .forGetter(JPDMHeightDensityFunction::sourcePeakMeters),
            Codec.DOUBLE.optionalFieldOf("base_y", 63.0)
                    .forGetter(JPDMHeightDensityFunction::baseY),
            Codec.DOUBLE.optionalFieldOf("peak_y", 560.0)
                    .forGetter(JPDMHeightDensityFunction::peakY),
            Codec.BOOL.optionalFieldOf("isotropic_horizontal_scale", false)
                    .forGetter(JPDMHeightDensityFunction::isotropicHorizontalScale),
            Codec.STRING.optionalFieldOf("coordinate_mode", "centered")
                    .forGetter(JPDMHeightDensityFunction::coordinateMode),
            Codec.DOUBLE.optionalFieldOf("world_origin_x_m", 0.0)
                    .forGetter(JPDMHeightDensityFunction::worldOriginXMeters),
            Codec.DOUBLE.optionalFieldOf("world_origin_z_m", 0.0)
                    .forGetter(JPDMHeightDensityFunction::worldOriginZMeters)
    ).apply(instance, JPDMHeightDensityFunction::new));

    private static boolean manifestResourceForJapan(String value) {
        String n = value == null ? "" : value.trim().replace('\\', '/');
        while (n.startsWith("/")) n = n.substring(1);
        return n.equals("japan/manifest.json");
    }

    private static boolean effectivePeakGuard(double peak, double base) {
        return peak < base;
    }

    private static final CodecHolder<JPDMHeightDensityFunction> CODEC_HOLDER = CodecHolder.of(CODEC);

    @Override
    public double sample(DensityFunction.NoisePos pos) {
        if (metersPerBlock <= 0.0 || effectivePeakGuard(peakY, baseY) || sourcePeakMeters <= sourceBaseMeters) {
            return baseY;
        }

        double effectiveMetersPerBlock = metersPerBlock;
        double effectiveBaseY = baseY;
        double effectivePeakY = peakY;
        if (manifestResourceForJapan(resource) && JPDMSettings.isActive()) {
            effectiveMetersPerBlock = JPDMSettings.horizontalMetersPerBlock();
            effectiveBaseY = JPDMSettings.baseY();
            effectivePeakY = JPDMSettings.peakY();
        }
        if (isotropicHorizontalScale && !manifestResourceForJapan(resource)) {
            effectiveMetersPerBlock = (sourcePeakMeters - sourceBaseMeters)
                    / Math.max(1.0e-6, peakY - baseY);
        }
        if (effectiveMetersPerBlock <= 0.0) return baseY;

        String normalized = resource == null ? "" : resource.trim().replace('\\', '/');
        while (normalized.startsWith("/")) normalized = normalized.substring(1);
        boolean manifest = normalized.endsWith(".json");

        double xMeters;
        double zMeters;
        if (manifest) {
            JPDMTileManifest tileManifest = JapaneseTerrainData.loadManifest(normalized).orElse(null);
            if (tileManifest == null) return baseY;
            xMeters = tileManifest.worldOriginX() + pos.blockX() * effectiveMetersPerBlock;
            zMeters = tileManifest.worldOriginZ() + pos.blockZ() * effectiveMetersPerBlock;
        } else if ("world".equalsIgnoreCase(coordinateMode)) {
            xMeters = worldOriginXMeters + pos.blockX() * effectiveMetersPerBlock;
            zMeters = worldOriginZMeters + pos.blockZ() * effectiveMetersPerBlock;
        } else {
            JPDM1 data = JapaneseTerrainData.loadBundled(normalized).orElse(null);
            if (data == null) return baseY;
            double widthMeters = (data.header().width() - 1) * data.header().cellMeters();
            double heightMeters = (data.header().height() - 1) * data.header().cellMeters();
            xMeters = data.header().westMeters() + widthMeters * 0.5
                    + pos.blockX() * effectiveMetersPerBlock;
            zMeters = data.header().southMeters() + heightMeters * 0.5
                    + pos.blockZ() * effectiveMetersPerBlock;
        }

        float sourceHeight = JapaneseTerrainData.sampleHeightMeters(normalized, xMeters, zMeters);
        if (Float.isNaN(sourceHeight)) return baseY;

        double normalizedHeight = (sourceHeight - sourceBaseMeters)
                / Math.max(1.0e-6, sourcePeakMeters - sourceBaseMeters);
        normalizedHeight = Math.max(0.0, Math.min(1.0, normalizedHeight));

        // Arnis-style scale: change both horizontal footprint and vertical
        // relief before mapping into the user-selected Minecraft Y interval.
        if (manifestResourceForJapan(resource) && JPDMSettings.isActive()) {
            double v = JPDMSettings.verticalReliefFactor();
            normalizedHeight = Math.pow(normalizedHeight, 1.0 / Math.max(1.0e-6, v));
        }

        normalizedHeight = Math.max(0.0, Math.min(1.0, normalizedHeight));
        return effectiveBaseY + normalizedHeight * (effectivePeakY - effectiveBaseY);
    }

    @Override
    public double minValue() {
        return Math.min(baseY, peakY);
    }

    @Override
    public double maxValue() {
        return Math.max(baseY, peakY);
    }

    @Override
    public CodecHolder<? extends DensityFunction> getCodecHolder() {
        return CODEC_HOLDER;
    }
}
