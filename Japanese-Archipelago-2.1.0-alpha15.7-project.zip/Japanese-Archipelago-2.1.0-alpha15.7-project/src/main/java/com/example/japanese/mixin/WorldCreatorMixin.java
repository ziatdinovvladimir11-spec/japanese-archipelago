package com.example.japanese.mixin;

import com.example.japanese.JapaneseArchipelagoWorldgen;
import com.example.japanese.client.JapaneseArchipelagoSettingsScreen;
import net.minecraft.client.gui.screen.world.CreateWorldScreen;
import net.minecraft.client.gui.screen.world.LevelScreenProvider;
import net.minecraft.client.gui.screen.world.WorldCreator;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.gen.WorldPreset;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(WorldCreator.class)
public abstract class WorldCreatorMixin {
    @Shadow private WorldCreator.WorldType worldType;

    @Inject(method = "getLevelScreenProvider", at = @At("HEAD"), cancellable = true)
    private void japaneseArchipelago$provideSettingsScreen(
            CallbackInfoReturnable<@Nullable LevelScreenProvider> cir) {
        if (worldType == null) {
            return;
        }

        RegistryEntry<WorldPreset> preset = worldType.preset();
        if (preset == null) {
            return;
        }

        if (preset.getKey().isPresent()
                && preset.getKey().get().getValue().equals(JapaneseArchipelagoWorldgen.REAL_WORLD_PRESET)) {
            cir.setReturnValue(JapaneseArchipelagoSettingsScreen::new);
        }
    }
}
