package com.example.japanese;

import com.example.japanese.terrain.JapaneseDensityFunctions;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class JapaneseArchipelagoMod implements ModInitializer {
    public static final String MOD_ID = "japanese_archipelago";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        JapaneseDensityFunctions.init();
        LOGGER.info("Japanese Archipelago world preset loaded.");
    }
}
