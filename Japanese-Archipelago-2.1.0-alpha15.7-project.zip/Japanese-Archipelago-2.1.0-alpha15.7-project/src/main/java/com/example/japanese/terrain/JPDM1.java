package com.example.japanese.terrain;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;

/**
 * Small, immutable-in-practice reader for JPDM1. Runtime sampling is bilinear and
 * allocation-free after construction. The reader is intentionally independent of
 * the Minecraft renderer and can be used by the terrain adapter and diagnostics.
 */
public final class JPDM1 {
    public static final int FLAG_HEIGHT = 1;
    public static final int FLAG_SLOPE = 2;
    public static final int FLAG_CURVATURE = 4;

    private final JPDMHeader header;
    private final float[] heightMeters;
    private final float[] slopeDegrees;
    private final float[] curvature;
    private final float minHeightMeters;
    private final float maxHeightMeters;

    private JPDM1(JPDMHeader header, float[] height, float[] slope, float[] curvature) {
        this.header = header;
        this.heightMeters = height;
        this.slopeDegrees = slope;
        this.curvature = curvature;
        float min = Float.POSITIVE_INFINITY;
        float max = Float.NEGATIVE_INFINITY;
        for (float value : height) {
            if (!Float.isNaN(value)) {
                min = Math.min(min, value);
                max = Math.max(max, value);
            }
        }
        this.minHeightMeters = min;
        this.maxHeightMeters = max;
    }

    public static JPDM1 load(InputStream source) throws IOException {
        try (GZIPInputStream gzip = new GZIPInputStream(source);
             DataInputStream in = new DataInputStream(new BufferedInputStream(gzip))) {
            JPDMHeader header = JPDMHeader.read(in);
            if (header.version() != 1) {
                throw new IOException("Unsupported JPDM1 version: " + header.version());
            }
            int cells = Math.multiplyExact(header.width(), header.height());
            float[] h = readQuarterMeter(in, cells);
            float[] s = (header.flags() & FLAG_SLOPE) != 0 ? readHundredth(in, cells) : null;
            float[] c = (header.flags() & FLAG_CURVATURE) != 0 ? readThousandth(in, cells) : null;
            return new JPDM1(header, h, s, c);
        }
    }

    private static float[] readQuarterMeter(DataInputStream in, int count) throws IOException {
        float[] result = new float[count];
        for (int i = 0; i < count; i++) {
            short raw = readLEShort(in);
            result[i] = raw == (short) -32768 ? Float.NaN : raw / 4.0f;
        }
        return result;
    }

    private static float[] readHundredth(DataInputStream in, int count) throws IOException {
        float[] result = new float[count];
        for (int i = 0; i < count; i++) result[i] = (readLEShort(in) & 0xFFFF) / 100.0f;
        return result;
    }

    private static float[] readThousandth(DataInputStream in, int count) throws IOException {
        float[] result = new float[count];
        for (int i = 0; i < count; i++) result[i] = readLEShort(in) / 1000.0f;
        return result;
    }

    private static short readLEShort(DataInputStream in) throws IOException {
        int lo = in.readUnsignedByte();
        int hi = in.readUnsignedByte();
        return (short) (lo | (hi << 8));
    }

    public JPDMHeader header() { return header; }

    public float minHeightMeters() { return minHeightMeters; }

    public float maxHeightMeters() { return maxHeightMeters; }

    public float sampleHeightMeters(double xMeters, double zMeters) {
        double gx = (xMeters - header.westMeters()) / header.cellMeters();
        double gz = (zMeters - header.southMeters()) / header.cellMeters();
        gx = Math.max(0.0, Math.min(header.width() - 1.000001, gx));
        gz = Math.max(0.0, Math.min(header.height() - 1.000001, gz));
        int x0 = (int) Math.floor(gx);
        int z0 = (int) Math.floor(gz);
        int x1 = Math.min(header.width() - 1, x0 + 1);
        int z1 = Math.min(header.height() - 1, z0 + 1);
        float tx = (float) (gx - x0);
        float tz = (float) (gz - z0);
        float a = value(heightMeters, x0, z0);
        float b = value(heightMeters, x1, z0);
        float c = value(heightMeters, x0, z1);
        float d = value(heightMeters, x1, z1);
        return bilinear(a, b, c, d, tx, tz);
    }

    private float value(float[] data, int x, int z) {
        return data[z * header.width() + x];
    }

    private static float bilinear(float a, float b, float c, float d, float tx, float tz) {
        // Missing edge samples are ignored rather than producing a giant negative spike.
        float ab = blendFinite(a, b, tx);
        float cd = blendFinite(c, d, tx);
        if (Float.isNaN(ab)) return cd;
        if (Float.isNaN(cd)) return ab;
        return ab + tz * (cd - ab);
    }

    private static float blendFinite(float a, float b, float t) {
        if (Float.isNaN(a) && Float.isNaN(b)) return Float.NaN;
        if (Float.isNaN(a)) return b;
        if (Float.isNaN(b)) return a;
        return a + t * (b - a);
    }
}
