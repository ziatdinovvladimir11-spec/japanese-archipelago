package com.example.japanese;

import net.minecraft.util.Identifier;

/** Stable identifiers for addons such as Sengoku Jidai. No client hooks or renderer mixins. */
public final class JapaneseArchipelagoWorldgen {
    public static final Identifier DIMENSION_TYPE = Identifier.of(JapaneseArchipelagoMod.MOD_ID, "japanese");
    public static final Identifier DIMENSION = Identifier.of(JapaneseArchipelagoMod.MOD_ID, "japanese");
    public static final Identifier NOISE_SETTINGS = Identifier.of(JapaneseArchipelagoMod.MOD_ID, "japanese");
    public static final Identifier WORLD_PRESET = Identifier.of(JapaneseArchipelagoMod.MOD_ID, "japanese");
    public static final Identifier REAL_WORLD_PRESET = Identifier.of(JapaneseArchipelagoMod.MOD_ID, "japan_real");
    public static final Identifier REAL_NOISE_SETTINGS = Identifier.of(JapaneseArchipelagoMod.MOD_ID, "japan_real");

    private JapaneseArchipelagoWorldgen() {}
}
