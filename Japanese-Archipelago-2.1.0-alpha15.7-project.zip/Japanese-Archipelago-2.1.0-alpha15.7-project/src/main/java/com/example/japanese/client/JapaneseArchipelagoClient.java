package com.example.japanese.client;

import net.fabricmc.api.ClientModInitializer;

public final class JapaneseArchipelagoClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // The settings screen is provided directly by the WorldCreator mixin for japan_real.
    }
}
