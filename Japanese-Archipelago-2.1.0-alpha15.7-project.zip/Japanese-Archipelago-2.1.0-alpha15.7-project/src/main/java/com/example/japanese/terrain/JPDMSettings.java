package com.example.japanese.terrain;

/** Runtime settings selected from the Japanese Archipelago world-creation screen. */
public final class JPDMSettings {
    public static final double DEFAULT_WORLD_SCALE = 1.0;
    public static final double DEFAULT_BASE_Y = 63.0;
    public static final double DEFAULT_PEAK_Y = 560.0;
    public static final double DEFAULT_REFERENCE_HORIZONTAL_METERS_PER_BLOCK = 7.6;

    private static volatile boolean customActive = false;
    private static volatile double worldScale = DEFAULT_WORLD_SCALE;
    private static volatile double baseY = DEFAULT_BASE_Y;
    private static volatile double peakY = DEFAULT_PEAK_Y;
    private static volatile boolean preserveFineRelief = true;

    private JPDMSettings() {}

    public static void apply(double scale, double base, double peak, boolean fineRelief) {
        worldScale = Math.max(0.05, Math.min(8.0, scale));
        baseY = Math.max(-64.0, Math.min(319.0, base));
        peakY = Math.max(baseY + 1.0, Math.min(560.0, peak));
        preserveFineRelief = fineRelief;
        customActive = true;
    }

    public static boolean isActive() { return customActive; }
    public static double worldScale() { return worldScale; }
    public static double baseY() { return baseY; }
    public static double peakY() { return peakY; }
    public static boolean preserveFineRelief() { return preserveFineRelief; }

    /**
     * Arnis-style scale semantics: higher scale means the represented geography
     * occupies more Minecraft X/Z blocks. One reference block represents
     * DEFAULT_REFERENCE_HORIZONTAL_METERS_PER_BLOCK real metres at 1.0x.
     */
    public static double horizontalMetersPerBlock() {
        return DEFAULT_REFERENCE_HORIZONTAL_METERS_PER_BLOCK / worldScale;
    }

    /**
     * Proportional vertical relief factor. This affects the relief before it is
     * normalized into the requested baseY..peakY interval; it therefore changes
     * terrain proportions without changing the selected maximum elevation.
     */
    public static double verticalReliefFactor() {
        return Math.sqrt(worldScale);
    }
}
