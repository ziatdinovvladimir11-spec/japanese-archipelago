# NOTICE

Japanese Archipelago is an independent project.

Copyright (c) 2026 Vladimir Ziyatdinov & OpenAI ChatGPT.
Licensed under the MIT License.

This repository references the following external projects for research, interoperability or dependency purposes. Their code, assets and trademarks remain the property of their respective authors.

- Tectonic — Apollo / Apollounknowndev — https://github.com/Apollounknowndev/tectonic
- Lithostitched — Apollo / Apollounknowndev — https://github.com/Apollounknowndev/lithostitched
- Biomes O' Plenty — Glitchfiend — https://github.com/Glitchfiend/BiomesOPlenty
- TerraBlender — Glitchfiend — https://github.com/Glitchfiend/TerraBlender
- Arnis — Louis Erbkamm (louis-e) — https://github.com/louis-e/arnis
- Streams Reflowing — NiceJohn — https://www.curseforge.com/minecraft/mc-mods/streams-reflowing
- Sengoku Jidai — QwikSand — https://www.curseforge.com/minecraft/mc-mods/sengoku-jidai-japanese-overhaul

No source code or assets from the reference projects above are intentionally bundled in Japanese Archipelago unless separately documented under their own license.

For GSI-derived datasets, see the provenance and licensing checklist before redistribution. The distributable mod must not contain raw source datasets unless their applicable terms have been verified.
