@echo off
setlocal
cd /d "%~dp0.."
echo === Japanese Archipelago: REAL FUJI GSI TEST ===
python tools\download_real_fuji.py --radius 12
if errorlevel 1 exit /b 1
python tools\build_real_fuji.py --radius 12 --cell 50
if errorlevel 1 exit /b 1
echo.
echo Real Fuji JPDM created under input\jpdata\fuji
endlocal
