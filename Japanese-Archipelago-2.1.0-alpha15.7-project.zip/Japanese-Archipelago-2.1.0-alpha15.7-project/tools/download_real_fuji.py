#!/usr/bin/env python3
"""Download a real GSI DEM1A Fuji test region.

Uses official GSI XYZ DEM1A PNG tiles. Runtime Minecraft never accesses the network.
Default: zoom 15, radius 12 tiles around Fuji (25x25 tiles).
"""
from __future__ import annotations
import argparse
import math, time
from pathlib import Path
from gsi_download import download_with_retry, validate_png

TEMPLATE = "https://cyberjapandata.gsi.go.jp/xyz/dem1a_png/{z}/{x}/{y}.png"
Z = 15
FUJI_LON, FUJI_LAT = 138.7278, 35.3606

def lonlat_to_tile(lon, lat, z):
    n=2**z
    x=int((lon+180)/360*n)
    lat=max(-85.05112878,min(85.05112878,lat))
    r=math.radians(lat)
    y=int((1-math.asinh(math.tan(r))/math.pi)/2*n)
    return x,y

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--radius', type=int, default=12)
    ap.add_argument('--out', type=Path, default=Path('input/jpdata/fuji/dem1a_z15'))
    ap.add_argument('--delay', type=float, default=0.12)
    ap.add_argument('--attempts', type=int, default=5)
    args=ap.parse_args()
    cx,cy=lonlat_to_tile(FUJI_LON,FUJI_LAT,Z)
    total=(2*args.radius+1)**2
    done=0; bad=[]
    args.out.mkdir(parents=True,exist_ok=True)
    for y in range(cy-args.radius, cy+args.radius+1):
        for x in range(cx-args.radius, cx+args.radius+1):
            done += 1
            dst=args.out/f'dem1a_{Z}_{x}_{y}.png'
            if validate_png(dst):
                print(f'[{done}/{total}] cached {dst.name}')
                continue
            url=TEMPLATE.format(z=Z,x=x,y=y)
            print(f'[{done}/{total}] {url}')
            ok,tries,err=download_with_retry(url,dst,attempts=args.attempts,timeout=60.0)
            if not ok:
                bad.append((x,y,err))
                print(f'  WARN: {err}')
            time.sleep(args.delay)
    print(f'Completed {total}; failures {len(bad)}; output {args.out}')
    if bad:
        print('Retry the same command to fetch missing tiles.')
        raise SystemExit(2)

if __name__=='__main__': main()
