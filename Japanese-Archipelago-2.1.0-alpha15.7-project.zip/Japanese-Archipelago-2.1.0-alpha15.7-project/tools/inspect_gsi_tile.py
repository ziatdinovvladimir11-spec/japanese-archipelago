#!/usr/bin/env python3
"""Inspect one local GSI elevation PNG without contacting the network."""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
from PIL import Image

from gsi_png_pipeline import decode_gsi_png

def main():
    p=argparse.ArgumentParser()
    p.add_argument('png',type=Path)
    args=p.parse_args()
    arr=decode_gsi_png(args.png)
    valid=arr[np.isfinite(arr)]
    print(f'file: {args.png}')
    print(f'size: {arr.shape[1]}x{arr.shape[0]}')
    if valid.size:
        print(f'elevation_min_m: {float(valid.min()):.3f}')
        print(f'elevation_max_m: {float(valid.max()):.3f}')
        print(f'elevation_mean_m: {float(valid.mean()):.3f}')
    print(f'invalid_cells: {int(np.isnan(arr).sum())}')

if __name__ == '__main__':
    main()
