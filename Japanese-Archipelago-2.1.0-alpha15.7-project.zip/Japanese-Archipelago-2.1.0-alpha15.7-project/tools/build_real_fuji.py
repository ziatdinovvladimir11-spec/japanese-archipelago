#!/usr/bin/env python3
"""Build a real Fuji JPDM1 tile from GSI DEM1A XYZ PNG tiles."""
from __future__ import annotations
import argparse, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--radius',type=int,default=12)
    ap.add_argument('--cell',type=float,default=50.0)
    ap.add_argument('--out',type=Path,default=Path('input/jpdata/fuji'))
    args=ap.parse_args()
    cmd=[sys.executable,str(ROOT/'real_fuji_pipeline.py'),'build','--source','dem1a','--radius',str(args.radius),'--tiles',str(Path('input/jpdata/fuji/dem1a_z15')),'--out',str(args.out),'--cell',str(args.cell)]
    raise SystemExit(subprocess.call(cmd))
if __name__=='__main__': main()
