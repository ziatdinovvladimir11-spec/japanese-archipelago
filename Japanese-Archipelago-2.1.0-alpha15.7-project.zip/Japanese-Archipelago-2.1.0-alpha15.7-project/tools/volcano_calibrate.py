#!/usr/bin/env python3
"""Compute an isotropic volcano scale from source elevation and target Y span."""
from __future__ import annotations
import argparse

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--source-base-m", type=float, default=0.0)
    p.add_argument("--source-peak-m", type=float, default=3776.0)
    p.add_argument("--base-y", type=float, default=63.0)
    p.add_argument("--peak-y", type=float, default=560.0)
    a=p.parse_args()
    source_span=a.source_peak_m-a.source_base_m
    y_span=a.peak_y-a.base_y
    if source_span<=0 or y_span<=0:
        raise SystemExit("source span and Y span must be positive")
    m_per_block=source_span/y_span
    blocks_per_m=y_span/source_span
    print(f"source span: {source_span:.3f} m")
    print(f"Minecraft Y span: {y_span:.3f} blocks")
    print(f"isotropic horizontal scale: {m_per_block:.6f} m/block")
    print(f"vertical scale: {blocks_per_m:.6f} blocks/m")
    print("ratio: 1.000000")

if __name__ == '__main__': main()
