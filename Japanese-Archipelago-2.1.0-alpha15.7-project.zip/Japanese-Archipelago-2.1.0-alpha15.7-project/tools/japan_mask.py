#!/usr/bin/env python3
"""Build a non-rectangular Japan land/planning mask from GSI Global Map Japan.

Developer-time preprocessing only. The input is the official Global Map Japan
vector ZIP (for example gm-jpn-all_u_2_2.zip). The coastline layer is read
without manual extraction, converted from linework to polygons, repaired, and
optionally expanded with a metric coastal planning buffer.

The resulting mask is deliberately a polygon/multipolygon, never a rectangular
bounding box. It is intended to drive later GSI DEM tile planning.
"""
from __future__ import annotations

import argparse
import json
import math
import tempfile
import zipfile
from pathlib import Path

import shapefile
from pyproj import CRS, Transformer
from shapely.geometry import GeometryCollection, LineString, MultiLineString, mapping, shape
from shapely.ops import linemerge, polygonize, transform, unary_union

DEFAULT_OUT = Path("input/jpdata/japan/japan_land_mask.geojson")
DEFAULT_PLANNING_OUT = Path("input/jpdata/japan/japan_planning_mask.geojson")


def _find_member(names: list[str], stem: str, ext: str) -> str:
    needle = f"/{stem}{ext}".lower()
    direct = [n for n in names if n.lower().endswith(needle)]
    if direct:
        return direct[0]
    exact = [n for n in names if Path(n).name.lower() == f"{stem}{ext}".lower()]
    if exact:
        return exact[0]
    raise SystemExit(f"ZIP does not contain {stem}{ext}")


def extract_coastline(zip_path: Path, temp_dir: Path) -> Path:
    with zipfile.ZipFile(zip_path) as z:
        names = z.namelist()
        members = {
            ext: _find_member(names, "coastl_jpn", ext)
            for ext in (".shp", ".shx", ".dbf", ".prj")
        }
        for name in members.values():
            target = temp_dir / Path(name).name
            target.write_bytes(z.read(name))
    return temp_dir / "coastl_jpn.shp"


def read_lines(shp_path: Path):
    lines = []
    with shapefile.Reader(str(shp_path)) as reader:
        shape_type = reader.shapeType
        shapes = reader.shapes()
    for shp in shapes:
        if shp.shapeType not in (shapefile.POLYLINE, shapefile.POLYLINEZ, shapefile.POLYLINEM):
            continue
        points = shp.points
        parts = list(shp.parts) + [len(points)]
        for i in range(len(parts) - 1):
            pts = points[parts[i] : parts[i + 1]]
            if len(pts) >= 2:
                lines.append(LineString(pts))
    if not lines:
        raise SystemExit("No coastline linework found")
    return lines, shape_type


def _japan_lcc():
    """A Japan-wide metric projection suitable for a 25 km planning buffer."""
    return CRS.from_proj4(
        "+proj=lcc +lat_1=30 +lat_2=40 +lat_0=36 +lon_0=138 "
        "+datum=WGS84 +units=m +no_defs"
    )


def _metric_transforms():
    local = _japan_lcc()
    fwd = Transformer.from_crs("EPSG:4326", local, always_xy=True).transform
    inv = Transformer.from_crs(local, "EPSG:4326", always_xy=True).transform
    return fwd, inv


def metric_buffer(geom, km: float):
    if km <= 0:
        return geom
    fwd, inv = _metric_transforms()
    metric = transform(fwd, geom)
    buffered = metric.buffer(km * 1000.0, quad_segs=8)
    return transform(inv, buffered)


def _extract_linework(geom):
    if geom.is_empty:
        return []
    if geom.geom_type == "LineString":
        return [geom]
    if geom.geom_type == "MultiLineString":
        return list(geom.geoms)
    if geom.geom_type == "GeometryCollection":
        out = []
        for child in geom.geoms:
            out.extend(_extract_linework(child))
        return out
    return []


def _extract_polygons(geom):
    if geom.is_empty:
        return []
    if geom.geom_type == "Polygon":
        return [geom]
    if geom.geom_type == "MultiPolygon":
        return list(geom.geoms)
    if geom.geom_type == "GeometryCollection":
        out = []
        for child in geom.geoms:
            out.extend(_extract_polygons(child))
        return out
    return []


def _close_with_metric_tolerance(lines, snap_m: float):
    """Close tiny endpoint gaps without feeding polygons into linemerge."""
    if snap_m <= 0:
        return lines
    fwd, inv = _metric_transforms()
    metric_lines = [transform(fwd, line) for line in lines]
    merged = unary_union(metric_lines)
    # buffer/squeeze only the LINEWORK. This is much cheaper than doing it on a
    # full Japan polygon and, importantly, avoids accidental Polygon output.
    closed = merged.buffer(snap_m, quad_segs=1).boundary.buffer(0)
    linework = _extract_linework(closed)
    if not linework:
        return lines
    return [transform(inv, line) for line in linework]


def build_land_from_coast(lines, snap_m: float = 1.0, simplify_m: float = 0.0):
    """Polygonize GSI coastline linework with bounded geometry operations."""
    print(f"coastline segments: {len(lines)}")
    print("phase 1/4: normalizing coastline linework...")
    linework = lines

    if simplify_m > 0:
        fwd, inv = _metric_transforms()
        linework = [
            transform(inv, transform(fwd, line).simplify(simplify_m, preserve_topology=True))
            for line in linework
        ]

    print("phase 2/4: joining coastline network...")
    merged = unary_union(linework)
    if merged.is_empty:
        raise SystemExit("Coastline union produced empty geometry")
    if snap_m > 0:
        print(f"  closing gaps up to {snap_m:g} m...")
        # Work on linework only. If the union is already polygonal, keep it;
        # otherwise extract the line components and polygonize them directly.
        if merged.geom_type in ("Polygon", "MultiPolygon"):
            candidates = _extract_polygons(merged)
        else:
            lines2 = _extract_linework(merged)
            if lines2:
                lines2 = _close_with_metric_tolerance(lines2, snap_m)
                merged = unary_union(lines2)
                candidates = []
            else:
                candidates = []
    else:
        candidates = _extract_polygons(merged)

    print("phase 3/4: polygonizing land...")
    if candidates:
        polys = candidates
    else:
        linework2 = _extract_linework(merged)
        if not linework2:
            raise SystemExit("No usable coastline linework remained after normalization")
        polys = list(polygonize(unary_union(linework2)))

    if not polys:
        raise SystemExit(
            "Could not polygonize coastline. Try --snap-m 2.0 or 5.0, or inspect the GSI linework."
        )

    print(f"  candidate polygons: {len(polys)}")
    print("phase 4/4: repairing and dissolving polygons...")
    repaired = [poly.buffer(0) for poly in polys if not poly.is_empty]
    repaired = [poly for geom in repaired for poly in _extract_polygons(geom)]
    if not repaired:
        raise SystemExit("Polygonized land geometry is empty after repair")

    geom = unary_union(repaired).buffer(0)
    if geom.is_empty or not geom.is_valid:
        geom = geom.buffer(0)
    if geom.is_empty:
        raise SystemExit("Polygonized land geometry is empty/invalid")
    return geom, len(polys)

def save_feature(path: Path, geom, properties: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({
            "type": "Feature",
            "properties": properties,
            "geometry": mapping(geom),
        }, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def describe(geom):
    parts = len(geom.geoms) if hasattr(geom, "geoms") else 1
    return {
        "geometry_type": geom.geom_type,
        "parts": parts,
        "valid": bool(geom.is_valid),
        "area_deg2": float(geom.area),
        "bounds": [float(v) for v in geom.bounds],
    }


def inspect_zip(zip_path: Path):
    with zipfile.ZipFile(zip_path) as z:
        names = z.namelist()
    for key in ("coastl_jpn", "inwatera_jpn", "polbnda_jpn"):
        found = [n for n in names if Path(n).stem.lower() == key]
        print(f"{key}: {'yes' if found else 'no'}")
    coast = [n for n in names if Path(n).stem.lower() == "coastl_jpn"]
    print(f"coastline members: {len(coast)}")
    print(f"zip: {zip_path}")


def main():
    p = argparse.ArgumentParser(description="Build an irregular Japan land mask from GSI Global Map Japan")
    sub = p.add_subparsers(dest="command", required=True)

    insp = sub.add_parser("inspect", help="inspect available coastline/water layers in the ZIP")
    insp.add_argument("zip", type=Path)

    build = sub.add_parser("build", help="polygonize the GSI coastline and optionally create a planning buffer")
    build.add_argument("zip", type=Path)
    build.add_argument("--snap-m", type=float, default=2.0, help="metric closure tolerance used before polygonization")
    build.add_argument("--simplify-m", type=float, default=0.0, help="optional metric simplification")
    build.add_argument("--buffer-km", type=float, default=25.0, help="coastal planning buffer; does not alter the land mask")
    build.add_argument("--out", type=Path, default=DEFAULT_OUT)
    build.add_argument("--planning-out", type=Path, default=DEFAULT_PLANNING_OUT)

    a = p.parse_args()
    if a.command == "inspect":
        inspect_zip(a.zip)
        return

    zip_path = a.zip.resolve()
    if not zip_path.exists():
        raise SystemExit(f"ZIP not found: {zip_path}")

    with tempfile.TemporaryDirectory(prefix="ja_gmjp_") as tmp:
        shp = extract_coastline(zip_path, Path(tmp))
        lines, shape_type = read_lines(shp)
        land, polygon_count = build_land_from_coast(lines, a.snap_m, a.simplify_m)
        planning = metric_buffer(land, a.buffer_km)

    land = land.buffer(0)
    planning = planning.buffer(0)
    save_feature(a.out, land, {
        "source": zip_path.name,
        "layer": "coastl_jpn",
        "polygonized_rings": polygon_count,
        "snap_m": a.snap_m,
        "simplify_m": a.simplify_m,
    })
    save_feature(a.planning_out, planning, {
        "source": zip_path.name,
        "layer": "coastl_jpn",
        "buffer_km": a.buffer_km,
        "purpose": "GSI DEM planning footprint only",
    })

    print(f"coastline records: {len(lines)}")
    print(f"source shapeType: {shape_type}")
    print(f"polygonized rings: {polygon_count}")
    print(f"land: {json.dumps(describe(land), ensure_ascii=False)}")
    print(f"planning: {json.dumps(describe(planning), ensure_ascii=False)}")
    print(f"land mask: {a.out}")
    print(f"planning mask: {a.planning_out}")


if __name__ == "__main__":
    main()
