# Japan mask workflow

## Input

Use the official GSI Global Map Japan vector ZIP, for example:

`gm-jpn-all_u_2_2.zip`

The ZIP must contain the `coastl_jpn` shapefile set (`.shp/.shx/.dbf/.prj`).

## 1. Inspect

```powershell
python .\tools\japan_mask.py inspect .\input\gm-jpn-all_u_2_2.zip
```

## 2. Build the irregular land mask

```powershell
python .\tools\japan_mask.py build .\input\gm-jpn-all_u_2_2.zip --buffer-km 25
```

Outputs:

- `input/jpdata/japan/japan_land_mask.geojson`
- `input/jpdata/japan/japan_planning_mask.geojson`

The land mask is built from coastline linework. The planning mask is a separate coastal buffer and is used only to select DEM tiles.

## 3. Preview

```powershell
python .\tools\japan_mask_preview.py .\build\jpdata\japan\japan_land_mask.geojson
```

## 4. Plan GSI tiles

For initial Japan coverage, use DEM10B to keep preprocessing manageable:

```powershell
python .\tools\japan_tile_planner.py .\build\jpdata\japan\japan_planning_mask.geojson --source dem10b
```

Use DEM5A/5B/5C later for targeted high-detail regions such as mountain belts and volcanoes.

## Design rules

- Never replace the geometry with a rectangular bounding box.
- Do not use an administrative boundary as the terrain mask.
- Keep the land mask and coastal planning buffer separate.
- Keep the final JPDM clipping mask independent from the GSI tile-selection geometry.
