#!/usr/bin/env python3
"""Plan optional DEM5A detail zones with a true metric buffer."""
from __future__ import annotations
import argparse, json, math
from pathlib import Path
from shapely.geometry import box, shape, mapping
from shapely.ops import unary_union, transform
from pyproj import CRS, Transformer

Z = 15
TEMPLATE = "https://cyberjapandata.gsi.go.jp/xyz/dem5a_png/{z}/{x}/{y}.png"


def load(path):
    o=json.loads(path.read_text(encoding="utf-8"))
    if o.get("type")=="FeatureCollection":
        return unary_union([shape(f["geometry"]) for f in o["features"] if f.get("geometry")])
    return shape(o.get("geometry",o))


def buffer_km(geom, km: float):
    if km <= 0: return geom
    lon0, lat0 = geom.centroid.x, geom.centroid.y
    crs = CRS.from_proj4(f"+proj=aeqd +lat_0={lat0} +lon_0={lon0} +datum=WGS84 +units=m +no_defs")
    fwd = Transformer.from_crs("EPSG:4326", crs, always_xy=True).transform
    inv = Transformer.from_crs(crs, "EPSG:4326", always_xy=True).transform
    return transform(inv, transform(fwd, geom).buffer(km*1000.0)).buffer(0)


def tile(lon, lat, z=Z):
    n=2**z; lat=max(-85.05112878,min(85.05112878,lat)); x=int((lon+180)/360*n); r=math.radians(lat); y=int((1-math.asinh(math.tan(r))/math.pi)/2*n); return x,y


def bounds(x,y,z=Z):
    n=2**z; w=x/n*360-180; e=(x+1)/n*360-180; no=math.degrees(math.atan(math.sinh(math.pi*(1-2*y/n)))); s=math.degrees(math.atan(math.sinh(math.pi*(1-2*(y+1)/n)))); return box(w,s,e,no)


def tiles(g):
    minx,miny,maxx,maxy=g.bounds; xa,yn=tile(minx,maxy); xb,ys=tile(maxx,miny); out=[]
    for y in range(min(yn,ys),max(yn,ys)+1):
        for x in range(min(xa,xb),max(xa,xb)+1):
            if g.intersects(bounds(x,y)): out.append((x,y))
    return set(out)


def main():
    p=argparse.ArgumentParser(); p.add_argument("zones",type=Path); p.add_argument("--buffer-km",type=float,default=5); p.add_argument("--out",type=Path,default=Path("input/jpdata/japan/japan_dem5a_detail_plan.json")); p.add_argument("--geojson-out",type=Path,default=Path("input/jpdata/japan/japan_dem5a_detail_tiles.geojson")); a=p.parse_args(); g=buffer_km(load(a.zones).buffer(0),a.buffer_km); ts=tiles(g); items=[]; feats=[]
    for x,y in sorted(ts,key=lambda q:(q[1],q[0])):
        it={"z":Z,"x":x,"y":y,"url":TEMPLATE.format(z=Z,x=x,y=y)}; items.append(it); feats.append({"type":"Feature","properties":it,"geometry":mapping(bounds(x,y))})
    a.out.parent.mkdir(parents=True,exist_ok=True); a.geojson_out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps({"format":"JapanDEM5ADetailPlan-v2","source":"dem5a","zoom":Z,"buffer_km":a.buffer_km,"tile_count":len(items),"zones_source":str(a.zones),"tiles":items},indent=2),encoding="utf-8")
    a.geojson_out.write_text(json.dumps({"type":"FeatureCollection","features":feats}),encoding="utf-8")
    print(f"zones: {a.zones}"); print(f"detail buffer: {a.buffer_km:g} km (metric AEQD)"); print(f"detail tiles: {len(items):,}")

if __name__=="__main__": main()
