# Real Japan preprocessing tools

Alpha8 adds an irregular Japan mask pipeline based on the GSI Global Map Japan coastline layer. The ZIP can remain untouched; `japan_mask.py` reads `coastl_jpn.shp/.shx/.dbf/.prj` directly from it.

Main commands:

```powershell
python .\tools\japan_mask.py inspect .\input\gm-jpn-all_u_2_2.zip
python .\tools\japan_mask.py build .\input\gm-jpn-all_u_2_2.zip --buffer-km 25
python .\tools\japan_mask_preview.py .\build\jpdata\japan\japan_land_mask.geojson
python .\tools\japan_tile_planner.py .\build\jpdata\japan\japan_planning_mask.geojson --source dem10b
```

The resulting tile plan is irregular: a tile is selected only when it intersects the planning mask.


## Production Japan terrain engine

See `JAPAN_REAL_ENGINE_WORKFLOW.md`. The intended path is mask → DEM10B manifest → resumable download → RGB VRT → sparse chunked JPDM1 → `japan_real` preset. DEM5A is reserved for explicit detail zones.
