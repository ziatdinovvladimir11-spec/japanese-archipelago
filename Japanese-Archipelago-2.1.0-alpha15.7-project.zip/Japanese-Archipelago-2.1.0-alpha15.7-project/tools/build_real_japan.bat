@echo off
setlocal
echo === Japanese Archipelago alpha 15.3: real-data pipeline ===
echo.
echo [1/6] Build authoritative Japan mask
python tools\japan_mask.py input\gm-jpn-all_u_2_2.zip --out-dir build\jpdata\japan
if errorlevel 1 exit /b 1
echo.
echo [2/6] Plan national DEM10B coverage
python tools\japan_region.py build\jpdata\japan\japan_land_mask.geojson --source dem10b --coverage land+coast --coast-ring-tiles 1 --game-cell-m 50
if errorlevel 1 exit /b 1
echo.
echo [3/6] Plan DEM5A detail zones
python tools\japan_detail_zones.py tools\detail_zones.initial.geojson --buffer-km 5
if errorlevel 1 exit /b 1
echo.
echo [4/6] Download DEM10B planned tiles
python tools\gsi_manifest_downloader.py input\jpdata\japan\japan_tile_plan.json --out build\jpdata\gsi_tiles\dem10b --workers 4
if errorlevel 1 exit /b 1
echo.
echo [5/6] Download DEM5A detail tiles and DEM1A Fuji tiles separately.
echo     Use the generated detail manifests and Fuji planner before running the exact downloader commands.
echo.
echo [6/6] Build the final JPDM dataset after DEM VRTs exist:
echo     python tools\japan_jpdm_builder.py BASE_DEM10B.vrt build\jpdata\japan\japan_land_mask.geojson --detail-input DETAIL_DEM5A.vrt --detail-zones build\jpdata\japan\detail_zones.geojson --superdetail-input FUJI_DEM1A.vrt --superdetail-zones build\jpdata\japan\fuji_ultra.geojson --out-dir input\jpdata\japan --cell 50 --chunk-cells 256
echo.
echo Pipeline planning complete.
endlocal
