# Japan real-data terrain engine workflow

This is the production path for the `japan_real` preset. The runtime does not perform
HTTP requests and does not need the raw GSI archive after preprocessing.

## 1. Build the authoritative mask

Use the Global Map Japan package already placed in `input/`:

```powershell
python .\tools\japan_mask.py input\gm-jpn-all_u_2_2.zip --out-dir build\jpdata\japan
```

The resulting `japan_land_mask.geojson` is the authoritative terrain boundary. It is never
replaced by a rectangular geographic bounding box.

## 2. Plan DEM10B coverage

```powershell
python .\tools\japan_region.py build\jpdata\japan\japan_land_mask.geojson --source dem10b --coverage land+coast --coast-ring-tiles 1 --game-cell-m 50
python .\tools\japan_coverage_report.py build\jpdata\japan\japan_tile_plan.json
```

No download happens in these commands. Inspect the manifest and storage report first.

## 3. Download exactly the planned tiles

```powershell
python .\tools\gsi_manifest_downloader.py build\jpdata\japan\japan_tile_plan.json --out build\jpdata\gsi_tiles --workers 4
```

The downloader is resumable: existing verified PNGs are retained and failures are recorded
in `download_audit.json`.

## 4. Build a virtual source mosaic

```powershell
python .\tools\gsi_xyz_vrt.py build\jpdata\gsi_tiles --source dem10b --zoom 14 --out build\jpdata\japan_dem10b.vrt
```

The VRT stays as a lightweight georeferencing index. It does not decode the RGB elevation
values until the JPDM builder reads a window. RGB data is sampled with nearest-neighbour
resampling before decoding so the 24-bit elevation code is never numerically interpolated.
The decoded 50 m JPDM grid is then bilinearly sampled at runtime.

## 5. Build sparse chunked JPDM

```powershell
python .\tools\japan_jpdm_builder.py build\jpdata\japan_dem10b.vrt build\jpdata\japan\japan_land_mask.geojson --out-dir build\jpdata\japan --cell 50 --chunk-cells 256
```

The builder:

- reprojects the source into a Japan-centred metric CRS;
- reads the raster window-by-window;
- clips all non-Japan cells to NoData;
- computes slope/curvature with a one-cell derivative halo;
- stores each 256×256 core as an independent JPDM1 tile;
- writes `input/jpdata/japan/manifest.json`.

The 256-cell chunk is approximately 12.8 km across at 50 m/cell. The Minecraft runtime
loads only the chunk needed by current generation and keeps a bounded LRU cache, rather than
loading the entire country.

## 6. Optional DEM5A detail zones

Create a GeoJSON FeatureCollection containing only deliberate detail zones. Good candidates
are volcanoes, major mountain belts, major river valleys and Sengoku-critical regions.
Do not draw a country-sized polygon here.

```powershell
python .\tools\japan_detail_zones.py build\jpdata\japan\detail_zones.geojson --buffer-km 5
```

The planner uses a true metric azimuthal-equidistant buffer; it does not approximate kilometres
by dividing longitude/latitude degrees.

## 7. Build and test

```powershell
.\gradlew.bat build
```

Choose the `japan_real` world preset only after `input/jpdata/japan/manifest.json` exists.
The normal `japanese` preset remains the procedural regression baseline. Fuji remains the
vertical/isotropic scaling regression test.

## 3A. First real-data acceptance region (recommended before nationwide download)

Use the deterministic Fuji–Suruga corridor test region. It downloads only a small 9×9 DEM10B
window at zoom 14 and builds the same chunked JPDM format used by the national pipeline:

```powershell
python .\tools\japan_real_test_region.py
```

Default center is **35.00 N, 138.55 E** with a radius of 4 XYZ tiles. Minecraft world `(0,0)` is
placed at the geographic center of the test region. The generated dataset lands directly in
`input/jpdata/japan`, so the existing `japan_real` preset uses it on the next build.

For a wider/narrower acceptance region, change `--radius`. Do not start with a nationwide radius.

Acceptance checks:

- `input/jpdata/japan/manifest.json` exists;
- `test_region_acceptance.json` records the chosen origin and source;
- `japan_real` generates mountains, foothills, lowlands and coastline without loading outside-country
  cells from the source raster;
- runtime logs show JPDM manifest/tile loading rather than the flat fallback;
- Voxy continues to consume ordinary generated chunks with no Japanese Archipelago renderer hook.
