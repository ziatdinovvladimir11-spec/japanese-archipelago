#!/usr/bin/env python3
"""Print the effective Fuji runtime scaling from a JPDM1 file."""
from __future__ import annotations
import argparse, gzip, struct
from pathlib import Path
HEADER = struct.Struct('<6sBBII f f f f')
MAGIC=b'JPDM1\0'

def read(path: Path):
    with gzip.open(path,'rb') as f:
        magic, version, flags, width, height, cell, west, south, nodata = HEADER.unpack(f.read(HEADER.size))
        if magic != MAGIC or version != 1:
            raise SystemExit('Not a JPDM1 v1 file')
        n=width*height
        raw=struct.unpack('<' + 'h'*n, f.read(2*n))
        vals=[v/4.0 for v in raw if v != -32768]
        return width,height,cell,min(vals),max(vals),west,south

def main():
    p=argparse.ArgumentParser()
    p.add_argument('jpdm', type=Path)
    p.add_argument('--source-base-m', type=float, default=0.0)
    p.add_argument('--source-peak-m', type=float, default=3776.0)
    p.add_argument('--base-y', type=float, default=63.0)
    p.add_argument('--peak-y', type=float, default=560.0)
    p.add_argument('--meters-per-block', type=float, default=50.0)
    p.add_argument('--isotropic', action='store_true')
    a=p.parse_args()
    w,h,cell,lo,hi,west,south=read(a.jpdm)
    vertical=(a.peak_y-a.base_y)/(a.source_peak_m-a.source_base_m)
    horizontal=(a.source_peak_m-a.source_base_m)/(a.peak_y-a.base_y) if a.isotropic else a.meters_per_block
    footprint_x=(w-1)*cell/horizontal
    footprint_z=(h-1)*cell/horizontal
    sample_hi_y=a.base_y + (hi-a.source_base_m)/(a.source_peak_m-a.source_base_m)*(a.peak_y-a.base_y)
    sample_lo_y=a.base_y + (lo-a.source_base_m)/(a.source_peak_m-a.source_base_m)*(a.peak_y-a.base_y)
    print(f'grid: {w} x {h}')
    print(f'cell: {cell:g} m')
    print(f'source range: {lo:.2f} .. {hi:.2f} m')
    print(f'source footprint: {(w-1)*cell/1000:.3f} x {(h-1)*cell/1000:.3f} km')
    print(f'horizontal scale: {horizontal:.6f} source m / Minecraft block')
    print(f'Minecraft footprint: {footprint_x:.1f} x {footprint_z:.1f} blocks')
    print(f'source remap: {a.source_base_m:g} .. {a.source_peak_m:g} m')
    print(f'vertical remap: Y={a.base_y:g} .. Y={a.peak_y:g}')
    print(f'vertical scale: {vertical:.6f} Minecraft blocks / source m')
    print(f'Fuji dataset samples -> Y={sample_lo_y:.2f} .. Y={sample_hi_y:.2f}')
    print(f'scale anisotropy ratio (horizontal m/block / vertical m/block): {horizontal/(1.0/vertical):.6f}')

if __name__=='__main__': main()
