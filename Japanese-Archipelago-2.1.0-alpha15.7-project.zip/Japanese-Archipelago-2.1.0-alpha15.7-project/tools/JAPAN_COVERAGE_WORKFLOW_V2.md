# Japan coverage workflow v2

Use the exact land mask as the authoritative terrain boundary. Plan DEM10B with a one-tile
coastal ring, then estimate download/storage before downloading. DEM5A is reserved for
explicit detail zones such as major volcanoes, high mountain ranges, important valleys,
and historically important regions.

Commands:

```powershell
python .\tools\japan_region.py .\build\jpdata\japan\japan_land_mask.geojson --source dem10b --coverage land+coast --coast-ring-tiles 1 --game-cell-m 50
python .\tools\japan_coverage_report.py .\build\jpdata\japan\japan_tile_plan.json
```

No command in this step downloads source DEM.
