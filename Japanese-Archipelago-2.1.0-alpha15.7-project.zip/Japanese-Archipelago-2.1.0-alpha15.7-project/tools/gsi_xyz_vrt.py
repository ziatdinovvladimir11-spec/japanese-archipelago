#!/usr/bin/env python3
"""Build a sparse georeferenced 3-band GDAL VRT from GSI XYZ PNG tiles.

Missing XYZ tiles are allowed. Gaps are represented as VRT NoData instead of
making the whole build fail. This is important because GSI DEM coverage can
have legitimate holes at the tile level.
"""
from __future__ import annotations

import argparse
import math
import os
from pathlib import Path
from xml.sax.saxutils import escape


def tile_bounds_mercator(x: int, y: int, z: int):
    n = 2 ** z
    west = x / n * 360.0 - 180.0
    east = (x + 1) / n * 360.0 - 180.0
    north = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
    south = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * (y + 1) / n))))
    R = 6378137.0
    def mx(lon): return R * math.radians(lon)
    def my(lat):
        lat = max(-85.05112878, min(85.05112878, lat))
        return R * math.log(math.tan(math.pi / 4.0 + math.radians(lat) / 2.0))
    return mx(west), my(south), mx(east), my(north)


def tile_files(folder: Path, source: str, z: int):
    out = []
    prefix = f"{source}_{z}_"
    for p in folder.glob(f"{prefix}*_*.png"):
        tail = p.stem[len(prefix):]
        try:
            x, y = map(int, tail.split("_", 1))
        except ValueError:
            continue
        out.append((x, y, p))
    return out


def main() -> int:
    p = argparse.ArgumentParser(description="Create a sparse georeferenced VRT for GSI XYZ RGB DEM tiles")
    p.add_argument("tiles", type=Path)
    p.add_argument("--source", required=True)
    p.add_argument("--zoom", type=int, required=True)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()

    items = tile_files(args.tiles, args.source, args.zoom)
    if not items:
        raise SystemExit("No matching PNG tiles found")
    xs = [x for x, _, _ in items]; ys = [y for _, y, _ in items]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)

    west = tile_bounds_mercator(x0, y0, args.zoom)[0]
    north = tile_bounds_mercator(x0, y0, args.zoom)[3]
    east = tile_bounds_mercator(x1, y1, args.zoom)[2]
    south = tile_bounds_mercator(x0, y1, args.zoom)[1]
    width = (x1 - x0 + 1) * 256
    height = (y1 - y0 + 1) * 256
    pixel_x = (east - west) / width
    pixel_y = (north - south) / height

    lines = [
        f'<VRTDataset rasterXSize="{width}" rasterYSize="{height}">',
        '<SRS dataAxisToSRSAxisMapping="1,2">EPSG:3857</SRS>',
        '<GeoTransform>%0.12f,%0.12f,0,%0.12f,0,%0.12f</GeoTransform>' % (west, pixel_x, north, -pixel_y),
    ]
    by_band_interp = {1: "Red", 2: "Green", 3: "Blue"}
    have = {(x, y) for x, y, _ in items}
    for band in range(1, 4):
        lines.append(f'<VRTRasterBand dataType="Byte" band="{band}">')
        lines.append(f'  <ColorInterp>{by_band_interp[band]}</ColorInterp>')
        lines.append('  <NoDataValue>0</NoDataValue>')
        for x, y, path in sorted(items, key=lambda t: (t[1], t[0])):
            tw, _, _, tn = tile_bounds_mercator(x, y, args.zoom)
            col = int(round((tw - west) / pixel_x))
            row = int(round((north - tn) / pixel_y))
            rel = os.path.relpath(path.resolve(), args.out.parent.resolve()).replace('\\', '/')
            lines += [
                '  <SimpleSource>',
                f'    <SourceFilename relativeToVRT="1">{escape(rel)}</SourceFilename>',
                f'    <SourceBand>{band}</SourceBand>',
                '    <SourceProperties RasterXSize="256" RasterYSize="256" DataType="Byte" BlockXSize="256" BlockYSize="1"/>',
                '    <SrcRect xOff="0" yOff="0" xSize="256" ySize="256"/>',
                f'    <DstRect xOff="{col}" yOff="{row}" xSize="256" ySize="256"/>',
                '  </SimpleSource>',
            ]
        lines.append('</VRTRasterBand>')
    lines.append('</VRTDataset>')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text("\n".join(lines), encoding="utf-8")
    expected = (x1 - x0 + 1) * (y1 - y0 + 1)
    missing = expected - len(have)
    print(f"tiles present: {len(items):,}")
    print(f"extent: x={x0}..{x1}, y={y0}..{y1}")
    print(f"implicit gaps: {missing:,}")
    print(f"vrt: {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
