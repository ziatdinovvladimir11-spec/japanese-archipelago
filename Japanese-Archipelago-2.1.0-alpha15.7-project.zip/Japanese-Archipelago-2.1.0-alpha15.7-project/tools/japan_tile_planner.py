#!/usr/bin/env python3
"""Generate an irregular GSI XYZ tile manifest from a Japan planning mask."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from shapely.geometry import box, mapping, shape
from shapely.ops import unary_union

TEMPLATES = {
    "dem1a": (17, "https://cyberjapandata.gsi.go.jp/xyz/dem1a_png/{z}/{x}/{y}.png"),
    "dem5a": (15, "https://cyberjapandata.gsi.go.jp/xyz/dem5a_png/{z}/{x}/{y}.png"),
    "dem5b": (15, "https://cyberjapandata.gsi.go.jp/xyz/dem5b_png/{z}/{x}/{y}.png"),
    "dem5c": (15, "https://cyberjapandata.gsi.go.jp/xyz/dem5c_png/{z}/{x}/{y}.png"),
    "dem10b": (14, "https://cyberjapandata.gsi.go.jp/xyz/dem_png/{z}/{x}/{y}.png"),
}


def load_geom(path: Path):
    obj = json.loads(path.read_text(encoding="utf-8"))
    if obj.get("type") == "FeatureCollection":
        return unary_union([shape(f["geometry"]) for f in obj["features"] if f.get("geometry")])
    return shape(obj.get("geometry", obj))


def lonlat_to_tile(lon: float, lat: float, z: int):
    n = 2 ** z
    lat = max(-85.05112878, min(85.05112878, lat))
    x = int((lon + 180.0) / 360.0 * n)
    r = math.radians(lat)
    y = int((1.0 - math.asinh(math.tan(r)) / math.pi) / 2.0 * n)
    return x, y


def tile_bounds(x: int, y: int, z: int):
    n = 2 ** z
    west = x / n * 360.0 - 180.0
    east = (x + 1) / n * 360.0 - 180.0
    north = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
    south = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * (y + 1) / n))))
    return box(west, south, east, north)


def main():
    p = argparse.ArgumentParser(description="Plan irregular GSI tile coverage")
    p.add_argument("planning_mask", type=Path)
    p.add_argument("--source", choices=sorted(TEMPLATES), default="dem10b")
    p.add_argument("--out", type=Path, default=Path("input/jpdata/japan/japan_tile_plan.json"))
    p.add_argument("--geojson-out", type=Path, default=Path("input/jpdata/japan/japan_planning_tiles.geojson"))
    a = p.parse_args()

    geom = load_geom(a.planning_mask).buffer(0)
    if geom.is_empty:
        raise SystemExit("Planning mask is empty")
    z, template = TEMPLATES[a.source]

    minx, miny, maxx, maxy = geom.bounds
    xa, yn = lonlat_to_tile(minx, maxy, z)
    xb, ys = lonlat_to_tile(maxx, miny, z)
    xlo, xhi = sorted((xa, xb))
    ylo, yhi = sorted((yn, ys))

    tiles = []
    features = []
    for y in range(ylo, yhi + 1):
        for x in range(xlo, xhi + 1):
            tb = tile_bounds(x, y, z)
            if not geom.intersects(tb):
                continue
            tile = {"z": z, "x": x, "y": y, "url": template.format(z=z, x=x, y=y)}
            tiles.append(tile)
            features.append({
                "type": "Feature",
                "properties": tile,
                "geometry": mapping(tb),
            })

    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.geojson_out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps({
        "format": "JapanTileManifest-v3",
        "source": a.source,
        "zoom": z,
        "tile_count": len(tiles),
        "planning_mask": str(a.planning_mask),
        "tiles": tiles,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    a.geojson_out.write_text(json.dumps({
        "type": "FeatureCollection",
        "features": features,
    }, ensure_ascii=False), encoding="utf-8")

    print(f"source: {a.source} / z={z}")
    print(f"tiles selected: {len(tiles)}")
    print(f"manifest: {a.out}")
    print(f"tile footprint: {a.geojson_out}")


if __name__ == "__main__":
    main()
