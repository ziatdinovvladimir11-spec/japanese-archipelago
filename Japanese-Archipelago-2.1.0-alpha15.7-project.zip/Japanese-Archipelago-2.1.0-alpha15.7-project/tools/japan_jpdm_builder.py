#!/usr/bin/env python3
"""Build a sparse, projected Japan JPDM1 dataset from a georeferenced raster/VRT.

The input is read window-by-window through a WarpedVRT. Non-Japan cells are clipped to
NoData using the authoritative land mask. One-cell halo is used for derivatives so
chunk edges do not acquire artificial slope discontinuities.
"""
from __future__ import annotations

import argparse
import gzip
import json
import math
import struct
from pathlib import Path

import numpy as np
from shapely.geometry import shape
from shapely.ops import transform as shp_transform

import rasterio
from rasterio.enums import Resampling
from rasterio.features import geometry_mask
from rasterio.transform import Affine
from rasterio.vrt import WarpedVRT
from rasterio.warp import calculate_default_transform
from pyproj import CRS, Transformer

MAGIC = b"JPDM1\0"
VERSION = 1
HEADER = struct.Struct("<6sBBII f f f f")
FLAG_HEIGHT = 1
FLAG_SLOPE = 2
FLAG_CURVATURE = 4


def load_geom(path: Path):
    obj = json.loads(path.read_text(encoding="utf-8"))
    if obj.get("type") == "FeatureCollection":
        geoms = [shape(f["geometry"]) for f in obj.get("features", []) if f.get("geometry")]
        if not geoms:
            raise ValueError("Land mask contains no geometries")
        from shapely.ops import unary_union
        return unary_union(geoms)
    return shape(obj.get("geometry", obj)).buffer(0)


def derivative_layers(height: np.ndarray, cell: float):
    valid = np.isfinite(height)
    if not valid.any():
        z = np.zeros_like(height, dtype=np.float32)
        return z, z
    filled = height.copy()
    median = float(np.nanmedian(filled))
    filled[~valid] = median
    gy, gx = np.gradient(filled, cell, cell, edge_order=1)
    slope = np.degrees(np.arctan(np.hypot(gx, gy))).astype(np.float32)
    gyy, _ = np.gradient(gy, cell, cell, edge_order=1)
    _, gxx = np.gradient(gx, cell, cell, edge_order=1)
    curvature = (gxx + gyy).astype(np.float32)
    slope[~valid] = np.nan
    curvature[~valid] = np.nan
    return slope, curvature


def write_jpdm_layers(path: Path, height: np.ndarray, slope: np.ndarray, curvature: np.ndarray,
                      cell: float, west: float, south: float):
    nodata = -32768.0
    h = np.nan_to_num(height, nan=nodata)
    s = np.nan_to_num(slope, nan=0.0)
    c = np.nan_to_num(curvature, nan=0.0)
    h16 = np.clip(np.rint(h * 4.0), -32768, 32767).astype("<i2")
    h16[h16 == -32768] = -32768
    s16 = np.clip(np.rint(s * 100.0), 0, 32767).astype("<i2")
    c16 = np.clip(np.rint(c * 1000.0), -32768, 32767).astype("<i2")
    header = HEADER.pack(MAGIC, VERSION, FLAG_HEIGHT | FLAG_SLOPE | FLAG_CURVATURE,
                         int(height.shape[1]), int(height.shape[0]), float(cell), float(west), float(south), nodata)
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wb", compresslevel=6) as out:
        out.write(header)
        out.write(h16.tobytes(order="C"))
        out.write(s16.tobytes(order="C"))
        out.write(c16.tobytes(order="C"))
    return float(np.nanmin(height)), float(np.nanmax(height))


def write_jpdm(path: Path, height: np.ndarray, cell: float, west: float, south: float):
    slope, curvature = derivative_layers(height, cell)
    return write_jpdm_layers(path, height, slope, curvature, cell, west, south)


def main() -> int:
    p = argparse.ArgumentParser(description="Projected GeoTIFF/VRT -> sparse Japan JPDM1")
    p.add_argument("input", type=Path, help="base DEM VRT/GeoTIFF (normally DEM10B)")
    p.add_argument("land_mask", type=Path, help="authoritative GeoJSON in EPSG:4326")
    p.add_argument("--detail-input", type=Path, help="optional higher-resolution DEM VRT/GeoTIFF (normally DEM5A)")
    p.add_argument("--detail-zones", type=Path, help="optional detail-zone GeoJSON in EPSG:4326")
    p.add_argument("--superdetail-input", type=Path, help="optional ultra-detail DEM VRT/GeoTIFF (normally DEM1A)")
    p.add_argument("--superdetail-zones", type=Path, help="optional ultra-detail-zone GeoJSON in EPSG:4326")
    p.add_argument("--out-dir", type=Path, default=Path("input/jpdata/japan"))
    p.add_argument("--cell", type=float, default=50.0)
    p.add_argument("--chunk-cells", type=int, default=256)
    p.add_argument("--target-crs", default="+proj=aeqd +lat_0=36 +lon_0=138 +datum=WGS84 +units=m +no_defs")
    p.add_argument("--world-origin-x-m", type=float, default=None)
    p.add_argument("--world-origin-z-m", type=float, default=None)
    p.add_argument("--prefix", default="tile")
    args = p.parse_args()

    if args.cell <= 0 or args.chunk_cells < 8:
        raise SystemExit("cell must be >0 and chunk-cells must be >=8")
    target_crs = CRS.from_user_input(args.target_crs)
    land_ll = load_geom(args.land_mask)
    to_target = Transformer.from_crs("EPSG:4326", target_crs, always_xy=True).transform
    land = shp_transform(to_target, land_ll).buffer(0)
    if land.is_empty:
        raise SystemExit("Projected land mask is empty")

    if bool(args.detail_input) != bool(args.detail_zones):
        raise SystemExit("--detail-input and --detail-zones must be supplied together")
    if bool(args.superdetail_input) != bool(args.superdetail_zones):
        raise SystemExit("--superdetail-input and --superdetail-zones must be supplied together")

    with rasterio.open(args.input) as src:
        if src.crs is None:
            raise SystemExit("Input raster/VRT has no CRS")
        dst_transform, dst_width, dst_height = calculate_default_transform(
            src.crs, target_crs, src.width, src.height, *src.bounds, resolution=(args.cell, args.cell)
        )
        with WarpedVRT(src, crs=target_crs, transform=dst_transform,
                       width=dst_width, height=dst_height, resampling=Resampling.nearest,
                       src_nodata=None, nodata=0) as vrt:
            transform = vrt.transform
            width, height = vrt.width, vrt.height
            detail_vrt = None
            detail_land = None
            detail_zone = None
            superdetail_vrt = None
            superdetail_zone = None
            superdetail_src = None
            if args.detail_input:
                detail_src = rasterio.open(args.detail_input)
                if detail_src.crs is None:
                    raise SystemExit("Detail raster/VRT has no CRS")
                detail_vrt = WarpedVRT(detail_src, crs=target_crs, transform=dst_transform,
                                       width=dst_width, height=dst_height, resampling=Resampling.nearest,
                                       src_nodata=None, nodata=0)
                detail_land_ll = load_geom(args.detail_zones)
                detail_zone = shp_transform(to_target, detail_land_ll).buffer(0)
            if args.superdetail_input:
                superdetail_src = rasterio.open(args.superdetail_input)
                if superdetail_src.crs is None:
                    raise SystemExit("Super-detail raster/VRT has no CRS")
                superdetail_vrt = WarpedVRT(superdetail_src, crs=target_crs, transform=dst_transform,
                                            width=dst_width, height=dst_height, resampling=Resampling.nearest,
                                            src_nodata=None, nodata=0)
                superdetail_zone_ll = load_geom(args.superdetail_zones)
                superdetail_zone = shp_transform(to_target, superdetail_zone_ll).buffer(0)
            bounds = vrt.bounds
            default_world_x = float(land.centroid.x)
            default_world_z = float(land.centroid.y)
            world_x = default_world_x if args.world_origin_x_m is None else args.world_origin_x_m
            world_z = default_world_z if args.world_origin_z_m is None else args.world_origin_z_m

            grid_origin_x = float(bounds.left)
            grid_origin_z = float(bounds.bottom)
            tiles = []
            stats = {"finite_cells": 0, "tiles": 0, "min_m": math.inf, "max_m": -math.inf}

            for row in range(0, height, args.chunk_cells):
                for col in range(0, width, args.chunk_cells):
                    core_h = min(args.chunk_cells, height - row)
                    core_w = min(args.chunk_cells, width - col)
                    halo_row = max(0, row - 1)
                    halo_col = max(0, col - 1)
                    halo_h = min(height - halo_row, core_h + (row > 0) + (row + core_h < height))
                    halo_w = min(width - halo_col, core_w + (col > 0) + (col + core_w < width))
                    window = rasterio.windows.Window(halo_col, halo_row, halo_w, halo_h)
                    raw = vrt.read(window=window, boundless=False)
                    if raw.ndim == 3 and raw.shape[0] >= 3 and raw.dtype == np.uint8:
                        rgb = raw[:3].astype(np.uint32)
                        code = (rgb[0] << 16) + (rgb[1] << 8) + rgb[2]
                        invalid = (rgb[0] == 128) & (rgb[1] == 0) & (rgb[2] == 0)
                        data = code.astype(np.float64) * 0.01
                        neg = code > (1 << 23)
                        data[neg] = (code[neg].astype(np.int64) - (1 << 24)) * 0.01
                        data[code == (1 << 23)] = np.nan
                        data[invalid] = np.nan
                        data = data.astype(np.float32)
                    else:
                        data = raw[0].astype(np.float32) if raw.ndim == 3 else raw.astype(np.float32)
                    wtransform = rasterio.windows.transform(window, transform)
                    mask = geometry_mask([land], out_shape=data.shape, transform=wtransform, invert=True)
                    if detail_vrt is not None:
                        raw_detail = detail_vrt.read(window=window, boundless=False)
                        if raw_detail.ndim == 3 and raw_detail.shape[0] >= 3 and raw_detail.dtype == np.uint8:
                            rgbd = raw_detail[:3].astype(np.uint32)
                            coded = (rgbd[0] << 16) + (rgbd[1] << 8) + rgbd[2]
                            invalid_d = (rgbd[0] == 128) & (rgbd[1] == 0) & (rgbd[2] == 0)
                            detail_data = coded.astype(np.float64) * 0.01
                            negd = coded > (1 << 23)
                            detail_data[negd] = (coded[negd].astype(np.int64) - (1 << 24)) * 0.01
                            detail_data[coded == (1 << 23)] = np.nan
                            detail_data[invalid_d] = np.nan
                            detail_data = detail_data.astype(np.float32)
                        else:
                            detail_data = raw_detail[0].astype(np.float32) if raw_detail.ndim == 3 else raw_detail.astype(np.float32)
                        zone_mask = geometry_mask([detail_zone], out_shape=data.shape, transform=wtransform, invert=True)
                        use_detail = zone_mask & np.isfinite(detail_data)
                        data[use_detail] = detail_data[use_detail]
                    if superdetail_vrt is not None:
                        raw_super = superdetail_vrt.read(window=window, boundless=False)
                        if raw_super.ndim == 3 and raw_super.shape[0] >= 3 and raw_super.dtype == np.uint8:
                            rgbs = raw_super[:3].astype(np.uint32)
                            codes = (rgbs[0] << 16) + (rgbs[1] << 8) + rgbs[2]
                            invalid_s = (rgbs[0] == 128) & (rgbs[1] == 0) & (rgbs[2] == 0)
                            super_data = codes.astype(np.float64) * 0.01
                            negs = codes > (1 << 23)
                            super_data[negs] = (codes[negs].astype(np.int64) - (1 << 24)) * 0.01
                            super_data[codes == (1 << 23)] = np.nan
                            super_data[invalid_s] = np.nan
                            super_data = super_data.astype(np.float32)
                        else:
                            super_data = raw_super[0].astype(np.float32) if raw_super.ndim == 3 else raw_super.astype(np.float32)
                        super_zone_mask = geometry_mask([superdetail_zone], out_shape=data.shape, transform=wtransform, invert=True)
                        use_super = super_zone_mask & np.isfinite(super_data)
                        data[use_super] = super_data[use_super]
                    data[~mask] = np.nan
                    if not np.isfinite(data).any():
                        continue
                    slope, curvature = derivative_layers(data, args.cell)
                    r0 = 1 if row > 0 else 0
                    c0 = 1 if col > 0 else 0
                    core = data[r0:r0+core_h, c0:c0+core_w]
                    core_slope = slope[r0:r0+core_h, c0:c0+core_w]
                    core_curvature = curvature[r0:r0+core_h, c0:c0+core_w]
                    # Ensure source grid order is south -> north for JPDM runtime.
                    core = np.flipud(core)
                    core_slope = np.flipud(core_slope)
                    core_curvature = np.flipud(core_curvature)
                    west = transform.c + col * transform.a
                    south = transform.f + (row + core_h) * transform.e
                    ix = int(math.floor((west - grid_origin_x) / (args.cell * args.chunk_cells) + 1e-9))
                    iz = int(math.floor((south - grid_origin_z) / (args.cell * args.chunk_cells) + 1e-9))
                    name = f"{args.prefix}_{ix}_{iz}.jpdm.gz"
                    out_path = args.out_dir / name
                    mn, mx = write_jpdm_layers(out_path, core, core_slope, core_curvature, args.cell, west, south)
                    stats["finite_cells"] += int(np.isfinite(core).sum())
                    stats["min_m"] = min(stats["min_m"], mn)
                    stats["max_m"] = max(stats["max_m"], mx)
                    stats["tiles"] += 1
                    tiles.append({"ix": ix, "iz": iz, "resource": f"japan/{name}"})
                    print(f"tile {ix},{iz}: {core.shape[1]}x{core.shape[0]} {mn:.1f}..{mx:.1f} m")

            if detail_vrt is not None:
                detail_vrt.close()
                detail_src.close()
            if superdetail_vrt is not None:
                superdetail_vrt.close()
                superdetail_src.close()

    if not tiles:
        raise SystemExit("No Japan land cells intersected the input raster")
    manifest = {
        "format": "JapanJPDMManifest-v1",
        "cell_m": args.cell,
        "chunk_cells": args.chunk_cells,
        "grid_origin_x_m": grid_origin_x,
        "grid_origin_z_m": grid_origin_z,
        "world_origin_x_m": world_x,
        "world_origin_z_m": world_z,
        "target_crs": target_crs.to_string(),
        "land_mask": str(args.land_mask),
        "input": str(args.input),
        "detail_input": str(args.detail_input) if args.detail_input else None,
        "detail_zones": str(args.detail_zones) if args.detail_zones else None,
        "superdetail_input": str(args.superdetail_input) if args.superdetail_input else None,
        "superdetail_zones": str(args.superdetail_zones) if args.superdetail_zones else None,
        "tiles": sorted(tiles, key=lambda t: (t["iz"], t["ix"])),
        "stats": stats,
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    (args.out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"manifest: {args.out_dir / 'manifest.json'}")
    print(f"tiles written: {stats['tiles']:,}")
    print(f"finite cells: {stats['finite_cells']:,}")
    print(f"elevation: {stats['min_m']:.2f}..{stats['max_m']:.2f} m")
    print(f"world origin: {world_x:.2f}, {world_z:.2f} m")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
