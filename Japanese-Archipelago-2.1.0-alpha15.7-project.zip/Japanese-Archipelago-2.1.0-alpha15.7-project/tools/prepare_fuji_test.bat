@echo off
setlocal
cd /d "%~dp0.."

echo =============================================================
echo Japanese Archipelago - Fuji GSI DEM test
 echo.
echo This downloads a resumable local mosaic around Mt. Fuji.
echo Existing tiles are reused. Minecraft runtime never uses HTTP.
echo =============================================================
python tools\fuji_region.py all --source dem5a --radius 8 --cell 50
if errorlevel 1 (
  echo.
  echo Fuji preparation failed. See the message above.
  pause
  exit /b 1
)
echo.
echo Done. Output is in build\jpdata\fuji\
 echo.
pause
