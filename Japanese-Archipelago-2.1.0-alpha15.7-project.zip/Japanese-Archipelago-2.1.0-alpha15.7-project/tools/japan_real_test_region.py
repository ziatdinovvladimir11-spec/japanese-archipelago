#!/usr/bin/env python3
"""Build a small real-data Japan test region for the `japan_real` preset.

Developer-time only. The script downloads official GSI DEM10B XYZ PNG tiles,
creates a local VRT, clips to the project's Japan land mask, and builds a
chunked JPDM1 dataset using the normal national runtime pipeline. Minecraft
never performs HTTP requests.

Default region: Fuji–Suruga corridor (35.0 N, 138.55 E), radius 4 XYZ tiles
at zoom 14. That is intentionally small enough for a first acceptance test
while still containing mountain, foothill, plain and coastal terrain.
"""
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
from pathlib import Path

from pyproj import CRS, Transformer
from shapely.geometry import Polygon, shape
from shapely.ops import transform as shp_transform

GSI_TEMPLATE = "https://cyberjapandata.gsi.go.jp/xyz/dem_png/{z}/{x}/{y}.png"
DEFAULT_LON = 138.55
DEFAULT_LAT = 35.00
DEFAULT_RADIUS = 4
DEFAULT_COVERAGE_BUFFER_KM = 2.0
DEFAULT_ZOOM = 14
DEFAULT_CELL = 50.0
TARGET_CRS = "+proj=aeqd +lat_0=36 +lon_0=138 +datum=WGS84 +units=m +no_defs"


def lonlat_to_tile(lon: float, lat: float, z: int) -> tuple[int, int]:
    n = 2 ** z
    lat = max(-85.05112878, min(85.05112878, lat))
    x = int((lon + 180.0) / 360.0 * n)
    r = math.radians(lat)
    y = int((1.0 - math.asinh(math.tan(r)) / math.pi) / 2.0 * n)
    return x, y


def tile_bounds(x: int, y: int, z: int) -> tuple[float, float, float, float]:
    n = 2 ** z
    west = x / n * 360.0 - 180.0
    east = (x + 1) / n * 360.0 - 180.0
    north = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
    south = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * (y + 1) / n))))
    return west, south, east, north


def run(cmd: list[str]) -> None:
    print("$", " ".join(map(str, cmd)))
    subprocess.run(cmd, check=True)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--lon", type=float, default=DEFAULT_LON)
    p.add_argument("--lat", type=float, default=DEFAULT_LAT)
    p.add_argument("--radius", type=int, default=DEFAULT_RADIUS,
                   help="candidate radius in XYZ tiles around the center tile")
    p.add_argument("--coverage-buffer-km", type=float, default=DEFAULT_COVERAGE_BUFFER_KM,
                   help="metric buffer around Japan land mask used to select candidate source tiles")
    p.add_argument("--zoom", type=int, default=DEFAULT_ZOOM)
    p.add_argument("--cell", type=float, default=DEFAULT_CELL,
                   help="target JPDM cell size in source metres")
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--attempts", type=int, default=5)
    p.add_argument("--timeout", type=float, default=60.0)
    p.add_argument("--delay", type=float, default=0.15)
    p.add_argument("--land-mask", type=Path,
                   default=Path("input/jpdata/japan/japan_land_mask.geojson"))
    p.add_argument("--tiles-dir", type=Path,
                   default=Path("input/jpdata/japan/test_region/tiles"))
    p.add_argument("--out-dir", type=Path,
                   default=Path("input/jpdata/japan"))
    p.add_argument("--keep-vrt", action="store_true")
    a = p.parse_args()

    if a.radius < 1:
        raise SystemExit("--radius must be >= 1")
    if a.cell <= 0:
        raise SystemExit("--cell must be > 0")
    if not a.land_mask.exists():
        raise SystemExit(
            f"Japan land mask not found: {a.land_mask}\n"
            "Build it first with: python .\\tools\\japan_mask.py "
            "input\\gm-jpn-all_u_2_2.zip --out-dir build\\jpdata\\japan"
        )

    cx, cy = lonlat_to_tile(a.lon, a.lat, a.zoom)
    # Select candidate tiles by intersection with a small metric buffer around the
    # authoritative Japan land mask instead of blindly downloading the full square.
    land_obj = json.loads(a.land_mask.read_text(encoding="utf-8"))
    land_ll = shape(land_obj.get("geometry", land_obj))
    if land_ll.is_empty:
        raise SystemExit("Japan land mask is empty")
    lcc = CRS.from_proj4("+proj=lcc +lat_1=30 +lat_2=40 +lat_0=36 +lon_0=138 +datum=WGS84 +units=m +no_defs")
    to_metric = Transformer.from_crs("EPSG:4326", lcc, always_xy=True).transform
    from_metric = Transformer.from_crs(lcc, "EPSG:4326", always_xy=True).transform
    coverage_geom = shp_transform(from_metric, shp_transform(to_metric, land_ll).buffer(a.coverage_buffer_km * 1000.0))

    candidate_coords = [(x, y) for y in range(cy - a.radius, cy + a.radius + 1)
                               for x in range(cx - a.radius, cx + a.radius + 1)]
    coords = []
    for x, y in candidate_coords:
        west, south, east, north = tile_bounds(x, y, a.zoom)
        tile_geom = Polygon([(west, south), (east, south), (east, north), (west, north), (west, south)])
        if coverage_geom.intersects(tile_geom):
            coords.append((x, y))
    if not coords:
        raise SystemExit("No source tiles intersect the requested land-mask coverage area")

    a.tiles_dir.mkdir(parents=True, exist_ok=True)

    manifest_path = a.tiles_dir.parent / "test_region_source_manifest.json"
    tiles = []
    for x, y in coords:
        tiles.append({
            "z": a.zoom,
            "x": x,
            "y": y,
            "url": GSI_TEMPLATE.format(z=a.zoom, x=x, y=y),
            "west": tile_bounds(x, y, a.zoom)[0],
            "south": tile_bounds(x, y, a.zoom)[1],
            "east": tile_bounds(x, y, a.zoom)[2],
            "north": tile_bounds(x, y, a.zoom)[3],
        })
    manifest = {
        "format": "JapanRealTestRegionSource-v1",
        "source": "dem10b",
        "zoom": a.zoom,
        "center": {"lon": a.lon, "lat": a.lat},
        "radius_tiles": a.radius,
        "coverage_buffer_km": a.coverage_buffer_km,
        "candidate_tile_count": len(candidate_coords),
        "tile_count": len(tiles),
        "tiles": tiles,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    # Reuse the project's reliable downloader. This keeps retry/validation logic in one place.
    downloader = Path(__file__).with_name("gsi_manifest_downloader.py")
    run([
        sys.executable, str(downloader), str(manifest_path),
        "--out", str(a.tiles_dir), "--workers", str(a.workers),
        "--attempts", str(a.attempts), "--timeout", str(a.timeout),
        "--delay", str(a.delay),
    ])

    # GSI may legitimately have 404 tiles inside a broad candidate rectangle.
    # For a stable acceptance test, anchor Minecraft (0,0) to the nearest tile
    # that actually exists instead of leaving the player at an unavailable hole.
    available = []
    for path in a.tiles_dir.glob(f"dem10b_{a.zoom}_*_*.png"):
        tail = path.stem.split("_", 3)
        if len(tail) != 4:
            continue
        try:
            available.append((int(tail[2]), int(tail[3]), path))
        except ValueError:
            continue
    if not available:
        raise SystemExit("Downloader produced no usable DEM10B tiles")
    available_coords = {(x, y) for x, y, _ in available}
    if (cx, cy) in available_coords:
        anchor_x, anchor_y = cx, cy
        print(f"source anchor tile available: {a.zoom}/{anchor_x}/{anchor_y}")
    else:
        anchor_x, anchor_y, _ = min(available, key=lambda t: (t[0]-cx)**2 + (t[1]-cy)**2)
        anchor_lon = (anchor_x + 0.5) / (2 ** a.zoom) * 360.0 - 180.0
        anchor_lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * (anchor_y + 0.5) / (2 ** a.zoom)))))
        print(f"center tile unavailable; using nearest available anchor {a.zoom}/{anchor_x}/{anchor_y} ({anchor_lat:.6f}, {anchor_lon:.6f})")
        a.lon, a.lat = anchor_lon, anchor_lat

    vrt = a.out_dir / "test_region_dem10b.vrt"
    vrt_builder = Path(__file__).with_name("gsi_xyz_vrt.py")
    run([
        sys.executable, str(vrt_builder), str(a.tiles_dir),
        "--source", "dem10b", "--zoom", str(a.zoom), "--out", str(vrt)
    ])

    # Put Minecraft world (0,0) at the geographic center of the test region.
    to_target = Transformer.from_crs("EPSG:4326", CRS.from_user_input(TARGET_CRS), always_xy=True)
    world_x, world_z = to_target.transform(a.lon, a.lat)

    builder = Path(__file__).with_name("japan_jpdm_builder.py")
    run([
        sys.executable, str(builder), str(vrt), str(a.land_mask),
        "--out-dir", str(a.out_dir), "--cell", str(a.cell),
        "--chunk-cells", "256", "--target-crs", TARGET_CRS,
        "--world-origin-x-m", f"{world_x:.6f}",
        "--world-origin-z-m", f"{world_z:.6f}",
        "--prefix", "test_region",
    ])

    # Keep a small acceptance-test record next to the generated manifest.
    acceptance = {
        "format": "JapanRealTestRegionAcceptance-v1",
        "source": "dem10b",
        "center": {"lon": a.lon, "lat": a.lat},
        "radius_tiles": a.radius,
        "zoom": a.zoom,
        "target_cell_m": a.cell,
        "target_crs": TARGET_CRS,
        "world_origin_m": {"x": world_x, "z": world_z},
        "jpdm_manifest": str(a.out_dir / "manifest.json"),
        "runtime_preset": "japanese_archipelago:japan_real",
        "notes": [
            "Test-region only; not a nationwide dataset.",
            "Minecraft runtime performs no network access.",
            "Regenerate freely; the source manifest is deterministic for the chosen center/radius/zoom.",
        ],
    }
    (a.out_dir / "test_region_acceptance.json").write_text(
        json.dumps(acceptance, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    print()
    print("REAL JAPAN TEST REGION READY")
    print(f"center: {a.lat:.6f}, {a.lon:.6f}")
    print(f"candidate square: {len(candidate_coords):,} tiles")
    print(f"mask-selected source tiles: {len(coords):,}")
    print(f"cell: {a.cell:g} m")
    print(f"world origin: {world_x:.2f}, {world_z:.2f} m")
    print(f"runtime manifest: {a.out_dir / 'manifest.json'}")
    print("player/test origin: Minecraft X=0, Z=0")
    print("next: .\\gradlew.bat build")
    if not a.keep_vrt:
        # The VRT is cheap, but keeping the default build output minimal is useful.
        vrt.unlink(missing_ok=True)
        print(f"removed transient VRT: {vrt}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
