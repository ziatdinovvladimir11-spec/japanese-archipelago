#!/usr/bin/env python3
"""Development-only GSI elevation-tile downloader.

This script is intentionally outside the Minecraft runtime. It downloads local
copies of GSI elevation PNG tiles for preprocessing. Review the current GSI terms
before redistribution of processed output.
"""
from __future__ import annotations
import argparse, math, time
from pathlib import Path
from urllib.request import Request, urlopen

TEMPLATES = {
    "dem1a": "https://cyberjapandata.gsi.go.jp/xyz/dem1a_png/{z}/{x}/{y}.png",
    "dem5a": "https://cyberjapandata.gsi.go.jp/xyz/dem5a_png/{z}/{x}/{y}.png",
    "dem5b": "https://cyberjapandata.gsi.go.jp/xyz/dem5b_png/{z}/{x}/{y}.png",
    "dem5c": "https://cyberjapandata.gsi.go.jp/xyz/dem5c_png/{z}/{x}/{y}.png",
    "dem10b": "https://cyberjapandata.gsi.go.jp/xyz/dem_png/{z}/{x}/{y}.png",
}

def lonlat_to_tile(lon: float, lat: float, z: int):
    n = 2 ** z
    x = int((lon + 180.0) / 360.0 * n)
    lat = max(-85.05112878, min(85.05112878, lat))
    r = math.radians(lat)
    y = int((1.0 - math.asinh(math.tan(r)) / math.pi) / 2.0 * n)
    return x, y

def download(url: str, out: Path):
    req = Request(url, headers={"User-Agent": "JapaneseArchipelago-dev/0.1"})
    with urlopen(req, timeout=30) as r:
        out.write_bytes(r.read())

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--source", choices=sorted(TEMPLATES), default="dem5a")
    p.add_argument("--zoom", type=int, default=8)
    p.add_argument("--bbox", required=True, help="west,south,east,north in lon,lat")
    p.add_argument("--out", type=Path, default=Path("build/jpdata/gsi_tiles"))
    p.add_argument("--delay", type=float, default=0.15)
    args = p.parse_args()
    west,south,east,north = map(float, args.bbox.split(','))
    x0,y1 = lonlat_to_tile(west, north, args.zoom)
    x1,y0 = lonlat_to_tile(east, south, args.zoom)
    if x1 < x0: x0,x1=x1,x0
    if y1 < y0: y0,y1=y1,y0
    args.out.mkdir(parents=True, exist_ok=True)
    template=TEMPLATES[args.source]
    count=0
    for y in range(y1, y0+1):
        for x in range(x0, x1+1):
            out=args.out / f"{args.source}_{args.zoom}_{x}_{y}.png"
            if out.exists():
                continue
            url=template.format(z=args.zoom,x=x,y=y)
            print(url)
            try:
                download(url,out)
            except Exception as e:
                print(f"WARN: {e}")
                if out.exists(): out.unlink()
            time.sleep(args.delay)
            count += 1
    print(f"Tiles processed: {count}. Output: {args.out}")

if __name__ == '__main__':
    main()
