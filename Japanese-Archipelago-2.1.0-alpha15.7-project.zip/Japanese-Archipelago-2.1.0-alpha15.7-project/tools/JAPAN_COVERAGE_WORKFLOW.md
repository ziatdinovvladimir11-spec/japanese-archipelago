# Japan coverage planning v3

The source DEM coverage is intentionally separate from the final Japan land mask.

## Recommended base coverage

`--coverage land+coast --coast-ring-tiles 1`

This selects every GSI tile intersecting the exact Japan land mask plus one source-tile
ring around those tiles. The ring is a small technical context for coastal interpolation;
it is **not** a 5–25 km ocean buffer.

## Planning only

The planner does not download DEM. It writes a manifest and a tile-footprint GeoJSON.

Example:

```powershell
python .\tools\japan_region.py .\build\jpdata\japan\japan_land_mask.geojson --source dem10b --coverage land+coast --coast-ring-tiles 1 --game-cell-m 50
```

The later preprocessing stage must clip the raster to `japan_land_mask.geojson`, so any
neighbor-country land that happens to share a source GSI tile is never promoted into the
Japanese land terrain.
