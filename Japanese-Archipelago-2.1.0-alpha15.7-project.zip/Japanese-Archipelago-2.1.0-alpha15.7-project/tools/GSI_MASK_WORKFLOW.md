# Japan mask / GSI tile workflow

The final Japan DEM is **not** downloaded from a rectangular Japan bounding box.
The developer supplies a non-rectangular GeoJSON Polygon/MultiPolygon representing
Japanese land/coast geometry. The tooling then adds only an optional coastal
planning buffer and selects intersecting GSI XYZ tiles.

## 1. Prepare the boundary

Put the official/current Japan coastline or land polygon here:

```text
input/japan_boundary.geojson
```

Do not silently substitute a third-party political boundary. Review the source,
license, date, datum and whether small islands are included.

## 2. Validate / normalize

```powershell
python tools\japan_mask.py input\japan_boundary.geojson
python tools\japan_mask_preview.py build\jpdata\japan\japan_land_mask.geojson
```

## 3. Plan DEM tiles

For nationwide macro terrain, start with DEM10B:

```powershell
python tools\japan_region.py build\jpdata\japan\japan_land_mask.geojson --source dem10b --buffer-km 25
```

For high-detail regional work, use DEM5A on a smaller region or selected tiles:

```powershell
python tools\japan_region.py build\jpdata\japan\japan_land_mask.geojson --source dem5a --buffer-km 25
```

The output `tile_manifest.json` is a list of only the GSI tiles that intersect
the irregular planning geometry. The final terrain land mask remains separate,
so the coastal buffer does not turn adjacent countries into terrain.

## 4. Download stage

The nationwide downloader should consume the manifest and use resumable retries,
PNG validation and a final audit before JPDM assembly. Never use `--allow-missing`
for acceptance data.
