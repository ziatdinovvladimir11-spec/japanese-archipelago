#!/usr/bin/env python3
"""Summarize Japan DEM coverage and estimate storage before any download."""
from __future__ import annotations
import argparse, json
from pathlib import Path

def fmt_bytes(n: float) -> str:
    units = ["B","KiB","MiB","GiB","TiB"]
    v=float(n); i=0
    while v>=1024 and i<len(units)-1:
        v/=1024; i+=1
    return f"{v:,.2f} {units[i]}"

def main():
    p=argparse.ArgumentParser(description="Estimate Japan DEM and JPDM storage before download")
    p.add_argument("manifest",type=Path)
    p.add_argument("--avg-tile-kb",type=float,default=90.0)
    p.add_argument("--cell-m",type=float,default=None)
    p.add_argument("--jpdm-bytes-per-cell",type=float,default=16.0,
                   help="planning envelope for elevation+derived fields before gzip")
    p.add_argument("--compression",type=float,default=0.55)
    a=p.parse_args()
    obj=json.loads(a.manifest.read_text(encoding="utf-8")); tiles=obj.get("tiles",[])
    if not tiles: raise SystemExit("Manifest contains no tiles")
    cell=float(a.cell_m if a.cell_m is not None else obj.get("game_cell_m",50.0))
    area=float(obj.get("estimated_land_area_km2",0.0))
    land_cells=int(obj.get("estimated_land_cells_50m",0))
    if land_cells<=0 and area>0: land_cells=round(area*1e6/(cell*cell))
    land=sum(t.get("zone")=="land" for t in tiles); coast=len(tiles)-land
    src=len(tiles)*a.avg_tile_kb*1024
    land_src=land*a.avg_tile_kb*1024; coast_src=coast*a.avg_tile_kb*1024
    raw=land_cells*a.jpdm_bytes_per_cell; gz=raw*max(.05,min(1.0,a.compression))
    print(f"manifest: {a.manifest}")
    print(f"source: {obj.get('source')} / z={obj.get('zoom')}")
    print(f"game grid: {cell:g} m")
    print(f"estimated land area: {area:,.1f} km2")
    print(f"estimated land cells: {land_cells:,}")
    print(f"land tiles: {land:,}")
    print(f"coastal-only tiles: {coast:,}")
    print(f"tiles total: {len(tiles):,}")
    print(f"assumed source PNG: {a.avg_tile_kb:g} KiB/tile")
    print(f"estimated source download: {fmt_bytes(src)}")
    print(f"  land-only: {fmt_bytes(land_src)}")
    print(f"  coastal-only: {fmt_bytes(coast_src)}")
    print(f"JPDM planning payload (pre-gzip): {fmt_bytes(raw)}")
    print(f"estimated JPDM gzip: {fmt_bytes(gz)}")
    print("No network access performed; storage estimate is parameterized.")
if __name__=="__main__": main()
