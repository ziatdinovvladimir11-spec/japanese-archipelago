#!/usr/bin/env python3
"""Resume-friendly downloader for an exact GSI XYZ tile manifest.

Developer-time only: the Minecraft runtime never downloads source data.
"""
from __future__ import annotations

import argparse
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from gsi_download import download_with_retry


def main() -> int:
    p = argparse.ArgumentParser(description="Download exactly the tiles listed by a GSI manifest")
    p.add_argument("manifest", type=Path)
    p.add_argument("--out", type=Path, default=Path("build/jpdata/gsi_tiles"))
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--attempts", type=int, default=6)
    p.add_argument("--timeout", type=float, default=60.0)
    p.add_argument("--backoff", type=float, default=1.6)
    p.add_argument("--delay", type=float, default=0.05)
    args = p.parse_args()

    obj = json.loads(args.manifest.read_text(encoding="utf-8"))
    tiles = obj.get("tiles", [])
    if not tiles:
        raise SystemExit("Manifest contains no tiles")
    args.out.mkdir(parents=True, exist_ok=True)

    source = obj.get("source", "dem")
    zoom = int(obj.get("zoom", 0))

    def one(tile: dict):
        x = int(tile["x"]); y = int(tile["y"]); z = int(tile.get("z", zoom))
        url = tile["url"]
        dst = args.out / f"{source}_{z}_{x}_{y}.png"
        if dst.exists():
            return True, tile, 0, "exists"
        ok, tries, err = download_with_retry(
            url, dst, attempts=args.attempts, timeout=args.timeout, backoff=args.backoff
        )
        if args.delay > 0:
            time.sleep(args.delay)
        return ok, tile, tries, err

    total = len(tiles)
    done = 0
    failures = []
    not_found = []
    print(f"manifest: {args.manifest}")
    print(f"source: {source} / z={zoom}")
    print(f"tiles: {total:,}; workers: {args.workers}")

    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as ex:
        futures = [ex.submit(one, t) for t in tiles]
        for fut in as_completed(futures):
            ok, tile, tries, err = fut.result()
            done += 1
            key = f"{tile.get('z', zoom)}/{tile['x']}/{tile['y']}"
            if ok:
                print(f"[{done}/{total}] OK {key} ({err})")
            else:
                err_text = str(err)
                if "404" in err_text or "HTTP Error 404" in err_text:
                    not_found.append({"tile": tile, "error": err_text, "attempts": tries})
                    print(f"[{done}/{total}] SKIP 404 {key}: source tile unavailable")
                else:
                    failures.append({"tile": tile, "error": err_text, "attempts": tries})
                    print(f"[{done}/{total}] FAIL {key}: {err_text}")

    audit = {
        "manifest": str(args.manifest),
        "source": source,
        "zoom": zoom,
        "requested": total,
        "failed": len(failures),
        "not_found": len(not_found),
        "failures": failures,
        "not_found_tiles": not_found,
    }
    audit_path = args.out / "download_audit.json"
    audit_path.write_text(json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"completed: {total - len(failures) - len(not_found):,}/{total:,}")
    print(f"404/unavailable: {len(not_found):,}")
    print(f"audit: {audit_path}")
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
