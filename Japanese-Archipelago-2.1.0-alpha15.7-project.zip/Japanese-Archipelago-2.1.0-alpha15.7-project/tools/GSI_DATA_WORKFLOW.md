# GSI data workflow

1. Download the exact GSI DEM meshes needed for the chosen test region using the official GSI service.
2. Keep the original ZIP/XML files outside the distributable mod repository unless their redistribution terms have been verified.
3. Convert the source data to GeoTIFF or NumPy using an offline GIS tool, or use the JPDM converter's supported local inputs.
4. Run the preprocessing pipeline to create JPDM1.
5. Record dataset type, GSI release date, bounding box, preprocessing version and source attribution in the manifest.
6. Only ship a derived dataset after checking the exact source terms.

GSI states that the DEM files are distributed in JPGIS (GML) format and documents the 1 m/5 m/10 m grid spacing and their source survey methods. citeturn282150search2turn282150search4
