#!/usr/bin/env python3
"""Render a grayscale preview of a Japan GeoJSON mask."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from PIL import Image, ImageDraw
from shapely.geometry import shape


def main():
    p = argparse.ArgumentParser()
    p.add_argument("geojson", type=Path)
    p.add_argument("--out", type=Path, default=Path("input/jpdata/japan/japan_mask_preview.png"))
    p.add_argument("--size", type=int, default=1800)
    a = p.parse_args()
    obj = json.loads(a.geojson.read_text(encoding="utf-8"))
    geom = shape(obj.get("geometry", obj))
    minx, miny, maxx, maxy = geom.bounds
    pad = max(maxx - minx, maxy - miny) * 0.025
    minx -= pad; maxx += pad; miny -= pad; maxy += pad
    sx = (a.size - 1) / (maxx - minx)
    sy = (a.size - 1) / (maxy - miny)
    im = Image.new("L", (a.size, a.size), 0)
    d = ImageDraw.Draw(im)

    def ring(coords):
        return [(int((x - minx) * sx), int((maxy - y) * sy)) for x, y in coords]

    polys = list(geom.geoms) if geom.geom_type == "MultiPolygon" else [geom]
    for poly in polys:
        d.polygon(ring(poly.exterior.coords), fill=255)
        for hole in poly.interiors:
            d.polygon(ring(hole.coords), fill=0)

    a.out.parent.mkdir(parents=True, exist_ok=True)
    im.save(a.out)
    print(f"preview: {a.out}")
    print(f"parts: {len(polys)}")
    print(f"extent: {minx:.4f},{miny:.4f} .. {maxx:.4f},{maxy:.4f}")


if __name__ == "__main__":
    main()
