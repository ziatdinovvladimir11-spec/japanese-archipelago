#!/usr/bin/env python3
"""Reliable developer-time downloader/validator for GSI XYZ PNG tiles."""
from __future__ import annotations

import io
import time
from pathlib import Path
from urllib.request import Request, urlopen

from PIL import Image


def validate_png(path: Path, expected_size=(256, 256)) -> bool:
    try:
        with Image.open(path) as im:
            im.verify()
        with Image.open(path) as im:
            return im.size == expected_size and im.mode in ("RGB", "RGBA", "P")
    except Exception:
        return False


def fetch_png(url: str, timeout: float = 60.0) -> bytes:
    req = Request(url, headers={
        "User-Agent": "JapaneseArchipelago-dev/2.1",
        "Accept": "image/png,*/*;q=0.8",
    })
    with urlopen(req, timeout=timeout) as resp:
        data = resp.read()
    with Image.open(io.BytesIO(data)) as im:
        im.verify()
    with Image.open(io.BytesIO(data)) as im:
        if im.size != (256, 256):
            raise ValueError(f"unexpected PNG size {im.size}")
    return data


def download_with_retry(url: str, dst: Path, attempts: int = 5,
                        timeout: float = 60.0, backoff: float = 1.5) -> tuple[bool, int, str | None]:
    last_error: str | None = None
    dst.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(1, attempts + 1):
        tmp = dst.with_suffix(dst.suffix + ".part")
        try:
            data = fetch_png(url, timeout=timeout)
            tmp.write_bytes(data)
            tmp.replace(dst)
            return True, attempt, None
        except Exception as exc:
            last_error = str(exc)
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass
            if attempt < attempts:
                time.sleep(backoff ** (attempt - 1))
    return False, attempts, last_error
