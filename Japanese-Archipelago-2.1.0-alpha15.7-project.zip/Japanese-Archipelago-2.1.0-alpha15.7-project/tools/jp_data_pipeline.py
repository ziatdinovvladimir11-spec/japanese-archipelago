#!/usr/bin/env python3
"""Offline Japanese terrain-data preprocessing for Japanese Archipelago.

The tool never connects to the network. It converts locally obtained elevation data
(e.g. GSI DEM GeoTIFF/ASCII/NumPy or GSI GML files) into a compact, game-friendly
JPDM1 binary containing a regular metric grid plus derived slope/curvature layers.

Output is deliberately NOT raw GSI source data. It is a derived, resampled product.
Check the applicable GSI/GSJ terms before redistributing any generated package.
"""
from __future__ import annotations

import argparse
import gzip
import json
import math
import struct
import sys
from pathlib import Path
from typing import Iterable

import numpy as np

try:
    import rasterio
except Exception:  # optional if only GML is used
    rasterio = None

try:
    import xml.etree.ElementTree as ET
except Exception:
    ET = None

MAGIC = b"JPDM1\0"
VERSION = 1
HEADER = struct.Struct("<6sBBII f f f f")
# magic, version, flags, width, height, cell_m, west_m, south_m, nodata

FLAG_HEIGHT = 1
FLAG_SLOPE = 2
FLAG_CURVATURE = 4


def parse_bbox(values: str | None):
    if not values:
        return None
    parts = [float(x) for x in values.split(",")]
    if len(parts) != 4:
        raise ValueError("bbox must be west,south,east,north")
    return tuple(parts)


def load_raster(path: Path) -> tuple[np.ndarray, object]:
    if rasterio is None:
        raise RuntimeError("rasterio is required for raster inputs")
    with rasterio.open(path) as src:
        arr = src.read(1, masked=True).filled(np.nan).astype(np.float32)
        return arr, src.transform


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _first_float_pair(text: str | None):
    if not text:
        return None
    vals = [float(v) for v in text.replace(',', ' ').split()]
    return vals[:2] if len(vals) >= 2 else None


def load_gsi_gml(path: Path) -> tuple[np.ndarray, tuple[float, float, float, float, float]]:
    """Parse the common GSI JPGIS DEM RectifiedGrid/tupleList layout.

    GSI documents that DEM samples are ordered west→east on each row, then
    continue on the next row southward. The parser reads RectifiedGrid limits,
    origin and offset vectors where present, and returns a georeferenced grid
    in latitude/longitude degrees. The final converter resamples it to a metric
    grid for JPDM1.
    """
    opener = gzip.open if path.suffix.lower() in {".gz", ".gzip"} else open
    with opener(path, "rb") as fh:
        root = ET.parse(fh).getroot()

    low = high = None
    tuple_text = None
    origin = None
    offsets: list[list[float]] = []
    srs_name = None

    for elem in root.iter():
        name = _local(elem.tag)
        txt = (elem.text or "").strip()
        if name == "low" and txt:
            try:
                low = [int(v) for v in txt.replace(",", " ").split()]
            except ValueError:
                pass
        elif name == "high" and txt:
            try:
                high = [int(v) for v in txt.replace(",", " ").split()]
            except ValueError:
                pass
        elif name == "tupleList" and txt:
            tuple_text = txt
        elif name == "pos" and txt and origin is None:
            origin = _first_float_pair(txt)
            srs_name = elem.attrib.get("srsName", srs_name)
        elif name == "offsetVector" and txt:
            pair = _first_float_pair(txt)
            if pair:
                offsets.append(pair)
        elif name == "lowerCorner" and txt and origin is None:
            origin = _first_float_pair(txt)
        elif name == "Envelope" and elem.attrib.get("srsName"):
            srs_name = elem.attrib.get("srsName")

    if not low or not high or tuple_text is None:
        raise ValueError(f"Unsupported GSI GML structure: {path.name}")

    width = high[0] - low[0] + 1
    height = high[1] - low[1] + 1
    if width <= 0 or height <= 0:
        raise ValueError(f"Invalid GSI grid dimensions in {path.name}")

    # GSI tupleList is row-major from the north-west corner. Each sample may be
    # encoded as "code,elevation" or just an elevation value. Missing cells are
    # commonly represented by blanks, which become NaN.
    flat: list[float] = []
    for raw in tuple_text.replace(";", " ").replace("\n", " ").split():
        token = raw.strip()
        if not token:
            continue
        if "," in token:
            token = token.rsplit(",", 1)[-1]
        try:
            flat.append(float(token))
        except ValueError:
            flat.append(np.nan)
    expected = width * height
    if len(flat) < expected:
        raise ValueError(f"GSI GML contains {len(flat)} values, expected {expected}: {path.name}")
    arr = np.asarray(flat[:expected], dtype=np.float32).reshape(height, width)

    # Prefer RectifiedGrid georeferencing. GSI stores geographic samples with
    # the first row at the northern edge, so latitude decreases down the array.
    if origin and len(offsets) >= 2:
        dx = offsets[0][0]
        dy = offsets[1][1]
        west = origin[0]
        north = origin[1]
        # return degrees as source units; the caller converts them to metres.
        return arr, (west, north, dx, dy, np.nan)

    raise ValueError(
        "GSI GML grid was parsed, but RectifiedGrid origin/offsetVector were not found. "
        "Use an offline GIS conversion to GeoTIFF or a GSI export retaining georeferencing."
    )

def open_input(path: Path):
    suffix = path.suffix.lower()
    if suffix in {".tif", ".tiff", ".vrt"}:
        return load_raster(path)
    if suffix in {".gml", ".xml", ".gz", ".gzip"}:
        return load_gsi_gml(path)
    if suffix == ".npy":
        arr = np.load(path).astype(np.float32)
        return arr, None
    if suffix == ".npz":
        data = np.load(path)
        key = "elevation" if "elevation" in data else data.files[0]
        return data[key].astype(np.float32), None
    raise ValueError(f"Unsupported input format: {path.suffix}")


def resize_grid(arr: np.ndarray, out_h: int, out_w: int) -> np.ndarray:
    """Area-ish bilinear resample using scipy when available, with numpy fallback."""
    from scipy.ndimage import zoom
    zy = out_h / arr.shape[0]
    zx = out_w / arr.shape[1]
    filled = arr.copy()
    if np.isnan(filled).any():
        med = np.nanmedian(filled)
        filled = np.where(np.isnan(filled), med, filled)
    return zoom(filled, (zy, zx), order=1, mode="nearest").astype(np.float32)


def compute_derivatives(height: np.ndarray, cell_m: float):
    gy, gx = np.gradient(height, cell_m, cell_m)
    slope = np.degrees(np.arctan(np.hypot(gx, gy))).astype(np.float32)
    gyy, _ = np.gradient(gy, cell_m, cell_m)
    _, gxx = np.gradient(gx, cell_m, cell_m)
    curvature = (gxx + gyy).astype(np.float32)
    return slope, curvature


def write_jpdm(path: Path, height: np.ndarray, cell_m: float, west_m: float, south_m: float):
    slope, curvature = compute_derivatives(height, cell_m)
    nodata = -32768.0
    h = np.nan_to_num(height, nan=nodata)
    s = np.nan_to_num(slope, nan=0.0)
    c = np.nan_to_num(curvature, nan=0.0)
    h16 = np.clip(np.rint(h * 4.0), -32767, 32767).astype("<i2")  # 0.25 m units
    s16 = np.clip(np.rint(s * 100.0), 0, 32767).astype("<i2")  # 0.01 degree
    c16 = np.clip(np.rint(c * 1000.0), -32767, 32767).astype("<i2")
    flags = FLAG_HEIGHT | FLAG_SLOPE | FLAG_CURVATURE
    header = HEADER.pack(MAGIC, VERSION, flags, h.shape[1], h.shape[0],
                         float(cell_m), float(west_m), float(south_m), float(nodata))
    with gzip.open(path, "wb", compresslevel=6) as out:
        out.write(header)
        out.write(h16.tobytes(order="C"))
        out.write(s16.tobytes(order="C"))
        out.write(c16.tobytes(order="C"))


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Offline Japan DEM → JPDM1 converter")
    p.add_argument("input", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("--cell", type=float, default=200.0, help="target cell size in meters")
    p.add_argument("--west-m", type=float, default=0.0)
    p.add_argument("--south-m", type=float, default=0.0)
    p.add_argument("--metadata", type=Path, help="optional JSON metadata output")
    p.add_argument("--gsi-gml", action="store_true", help="interpret GML origin/offset values as geographic degrees")
    args = p.parse_args(argv)

    arr, transform = open_input(args.input)
    if args.gsi_gml and transform is not None and rasterio is None:
        west_deg, north_deg, dx_deg, dy_deg, _ = transform
        # approximate metric spacing around the mean latitude; sufficient for
        # compact resampling before a more exact projected GIS stage is used.
        mean_lat = north_deg + dy_deg * max(0, arr.shape[0] - 1) * 0.5
        meters_per_deg_lat = 111_132.0
        meters_per_deg_lon = 111_320.0 * math.cos(math.radians(mean_lat))
        src_cell_x = abs(dx_deg) * meters_per_deg_lon
        src_cell_y = abs(dy_deg) * meters_per_deg_lat
        span_x = src_cell_x * arr.shape[1]
        span_y = src_cell_y * arr.shape[0]
        out_w = max(1, int(round(span_x / args.cell)))
        out_h = max(1, int(round(span_y / args.cell)))
        arr = resize_grid(arr, out_h, out_w)
        west = west_deg * meters_per_deg_lon
        south = (north_deg + dy_deg * arr.shape[0]) * meters_per_deg_lat
    elif transform is not None and rasterio is not None:
        # North-up raster: a=east-west pixel size, e/n offsets.
        src_cell_x = abs(transform.a)
        src_cell_y = abs(transform.e)
        west = float(transform.c)
        south = float(transform.f + transform.e * arr.shape[0])
        span_x = src_cell_x * arr.shape[1]
        span_y = src_cell_y * arr.shape[0]
        out_w = max(1, int(round(span_x / args.cell)))
        out_h = max(1, int(round(span_y / args.cell)))
        arr = resize_grid(arr, out_h, out_w)
    else:
        # For raw arrays, the source is assumed to already be on a metric grid.
        span_x = arr.shape[1] * args.cell
        span_y = arr.shape[0] * args.cell
        west = args.west_m
        south = args.south_m

    write_jpdm(args.output, arr, args.cell, west, south)
    if args.metadata:
        slope, curvature = compute_derivatives(arr, args.cell)
        meta = {
            "format": "JPDM1",
            "version": 1,
            "input": args.input.name,
            "cell_m": args.cell,
            "width": int(arr.shape[1]),
            "height": int(arr.shape[0]),
            "west_m": west,
            "south_m": south,
            "elevation_min_m": float(np.nanmin(arr)),
            "elevation_max_m": float(np.nanmax(arr)),
            "slope_p95_deg": float(np.nanpercentile(slope, 95)),
            "curvature_abs_p95": float(np.nanpercentile(np.abs(curvature), 95)),
            "notes": "Derived/resampled data. Do not treat as a redistribution of source data without checking source terms.",
        }
        args.metadata.parent.mkdir(parents=True, exist_ok=True)
        args.metadata.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {args.output} ({arr.shape[1]}x{arr.shape[0]}, {args.cell:g} m cells)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
