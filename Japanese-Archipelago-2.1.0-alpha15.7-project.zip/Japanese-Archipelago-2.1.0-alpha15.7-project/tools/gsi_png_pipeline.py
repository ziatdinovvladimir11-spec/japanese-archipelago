#!/usr/bin/env python3
"""GSI elevation PNG -> local metric grid -> JPDM1.

Development-time/offline tool. It can also optionally download GSI XYZ tiles when
run by a developer with Internet access, but Minecraft runtime never uses HTTP.

GSI PNG decoding follows the official 24-bit rule documented by the Geospatial
Information Authority of Japan (GSI):
    x = 2^16 R + 2^8 G + B
    x < 2^23: h = x * 0.01 m
    x == 2^23: N/A
    x > 2^23: h = (x - 2^24) * 0.01 m
with (128, 0, 0) used for invalid samples.
"""
from __future__ import annotations

import argparse
import gzip
import json
import math
import struct
import time
from pathlib import Path
from urllib.request import Request, urlopen

import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter, zoom

MAGIC = b"JPDM1\0"
VERSION = 1
HEADER = struct.Struct("<6sBBII f f f f")
FLAG_HEIGHT = 1
FLAG_SLOPE = 2
FLAG_CURVATURE = 4

TEMPLATES = {
    "dem1a": "https://cyberjapandata.gsi.go.jp/xyz/dem1a_png/{z}/{x}/{y}.png",
    "dem5a": "https://cyberjapandata.gsi.go.jp/xyz/dem5a_png/{z}/{x}/{y}.png",
    "dem5b": "https://cyberjapandata.gsi.go.jp/xyz/dem5b_png/{z}/{x}/{y}.png",
    "dem5c": "https://cyberjapandata.gsi.go.jp/xyz/dem5c_png/{z}/{x}/{y}.png",
    "dem10b": "https://cyberjapandata.gsi.go.jp/xyz/dem_png/{z}/{x}/{y}.png",
}


def lonlat_to_tile(lon: float, lat: float, z: int) -> tuple[int, int]:
    n = 2 ** z
    lat = max(-85.05112878, min(85.05112878, lat))
    x = int((lon + 180.0) / 360.0 * n)
    r = math.radians(lat)
    y = int((1.0 - math.asinh(math.tan(r)) / math.pi) / 2.0 * n)
    return x, y


def tile_to_lonlat(px: int, py: int, z: int) -> tuple[float, float]:
    npx = 256 * (2 ** z)
    lon = px / npx * 360.0 - 180.0
    t = math.pi * (1.0 - 2.0 * py / npx)
    lat = math.degrees(math.atan(math.sinh(t)))
    return lon, lat


def decode_gsi_png(path: Path) -> np.ndarray:
    image = Image.open(path).convert("RGB")
    rgb = np.asarray(image, dtype=np.uint32)
    x = (rgb[:, :, 0] << 16) + (rgb[:, :, 1] << 8) + rgb[:, :, 2]
    invalid = (rgb[:, :, 0] == 128) & (rgb[:, :, 1] == 0) & (rgb[:, :, 2] == 0)
    h = x.astype(np.float64) * 0.01
    neg = x > (1 << 23)
    h[neg] = (x[neg].astype(np.int64) - (1 << 24)) * 0.01
    h[x == (1 << 23)] = np.nan
    h[invalid] = np.nan
    return h.astype(np.float32)


def tile_files(folder: Path, source: str, zoom_level: int) -> dict[tuple[int, int], Path]:
    result: dict[tuple[int, int], Path] = {}
    prefix = f"{source}_{zoom_level}_"
    for p in folder.glob(f"{prefix}*_*.png"):
        tail = p.stem[len(prefix):]
        try:
            x_s, y_s = tail.split("_", 1)
            result[(int(x_s), int(y_s))] = p
        except ValueError:
            continue
    return result


def mosaic_tiles(files: dict[tuple[int, int], Path]) -> tuple[np.ndarray, tuple[int, int, int, int]]:
    if not files:
        raise ValueError("No matching GSI PNG tiles found")
    xs = [k[0] for k in files]
    ys = [k[1] for k in files]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    expected = (x1 - x0 + 1) * (y1 - y0 + 1)
    if len(files) != expected:
        missing = []
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                if (x, y) not in files:
                    missing.append((x, y))
        raise ValueError(f"Tile set has gaps: {len(missing)} missing, e.g. {missing[:5]}")
    first = decode_gsi_png(files[(x0, y0)])
    tile_h, tile_w = first.shape
    out = np.empty(((y1-y0+1)*tile_h, (x1-x0+1)*tile_w), dtype=np.float32)
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            tile = first if (x, y) == (x0, y0) else decode_gsi_png(files[(x, y)])
            out[(y-y0)*tile_h:(y-y0+1)*tile_h,
                (x-x0)*tile_w:(x-x0+1)*tile_w] = tile
    return out, (x0, x1, y0, y1)


def fill_nan(arr: np.ndarray) -> np.ndarray:
    out = arr.copy()
    if not np.isnan(out).any():
        return out
    # In a DEM mosaic, missing values are most common offshore. Use nearest-ish
    # propagation by repeated neighbour averaging rather than a huge blur.
    for _ in range(12):
        mask = np.isnan(out)
        if not mask.any():
            break
        acc = np.zeros_like(out, dtype=np.float64)
        cnt = np.zeros_like(out, dtype=np.float64)
        for dy, dx in ((-1,0),(1,0),(0,-1),(0,1)):
            shifted = np.roll(out, (dy, dx), axis=(0,1))
            valid = ~np.isnan(shifted)
            acc += np.where(valid, shifted, 0.0)
            cnt += valid
        repl = mask & (cnt > 0)
        out[repl] = (acc[repl] / cnt[repl]).astype(np.float32)
    # Any stubborn gaps become local median fallback.
    if np.isnan(out).any():
        med = float(np.nanmedian(out))
        out[np.isnan(out)] = med
    return out


def gsi_mosaic_cell_size_m(z: int, y_tile: int) -> float:
    # Approximate metric cell width/height at the mosaic latitude; only used for
    # the local Fuji prototype. Nationwide production will use a Japan projected CRS.
    lat0 = tile_to_lonlat(0, y_tile * 256 + 128, z)[1]
    n = 2 ** z
    meters_per_pixel_y = 40075016.68557849 * math.cos(math.radians(lat0)) / n / 256.0
    return meters_per_pixel_y


def resample_metric(arr: np.ndarray, source_cell_m: float, target_cell_m: float) -> np.ndarray:
    factor = source_cell_m / target_cell_m
    out_h = max(2, int(round(arr.shape[0] * factor)))
    out_w = max(2, int(round(arr.shape[1] * factor)))
    zy = out_h / arr.shape[0]
    zx = out_w / arr.shape[1]
    try:
        out = zoom(arr, (zy, zx), order=1, mode="nearest", prefilter=False, grid_mode=True)
    except TypeError:
        out = zoom(arr, (zy, zx), order=1, mode="nearest", prefilter=False)
    return out.astype(np.float32)


def derivatives(height: np.ndarray, cell_m: float):
    if height.shape[0] < 2 or height.shape[1] < 2:
        zeros = np.zeros_like(height, dtype=np.float32)
        return zeros, zeros
    gy, gx = np.gradient(height, cell_m, cell_m, edge_order=1)
    slope = np.degrees(np.arctan(np.hypot(gx, gy))).astype(np.float32)
    gyy, _ = np.gradient(gy, cell_m, cell_m, edge_order=1)
    _, gxx = np.gradient(gx, cell_m, cell_m, edge_order=1)
    curvature = (gxx + gyy).astype(np.float32)
    return slope, curvature


def write_jpdm(path: Path, height: np.ndarray, cell_m: float, west_m: float, south_m: float,
               source: str, zoom_level: int, tile_bounds: tuple[int,int,int,int],
               metadata_path: Path | None = None):
    slope, curvature = derivatives(height, cell_m)
    h = np.clip(np.rint(height * 4.0), -32767, 32767).astype("<i2")
    s = np.clip(np.rint(slope * 100.0), 0, 32767).astype("<i2")
    c = np.clip(np.rint(curvature * 1000.0), -32767, 32767).astype("<i2")
    flags = FLAG_HEIGHT | FLAG_SLOPE | FLAG_CURVATURE
    header = HEADER.pack(MAGIC, VERSION, flags, h.shape[1], h.shape[0],
                         float(cell_m), float(west_m), float(south_m), -32768.0)
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wb", compresslevel=6) as out:
        out.write(header)
        out.write(h.tobytes())
        out.write(s.tobytes())
        out.write(c.tobytes())
    if metadata_path:
        x0, x1, y0, y1 = tile_bounds
        metadata = {
            "format": "JPDM1",
            "version": 1,
            "source": source,
            "zoom": zoom_level,
            "tile_bounds": {"x0": x0, "x1": x1, "y0": y0, "y1": y1},
            "cell_m": cell_m,
            "width": int(height.shape[1]),
            "height": int(height.shape[0]),
            "west_m": west_m,
            "south_m": south_m,
            "elevation_min_m": float(np.nanmin(height)),
            "elevation_max_m": float(np.nanmax(height)),
            "slope_p95_deg": float(np.percentile(slope, 95)),
            "curvature_abs_p95": float(np.percentile(np.abs(curvature), 95)),
            "processing": [
                "GSI PNG RGB decode",
                "missing-cell fill",
                "local metric resampling",
                "JPDM1 derivation",
            ],
            "note": "Derived data. Check current GSI terms before redistribution.",
        }
        metadata_path.parent.mkdir(parents=True, exist_ok=True)
        metadata_path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")


def download_tiles(source: str, zoom_level: int, bbox: tuple[float,float,float,float], out: Path, delay: float):
    west, south, east, north = bbox
    x0, y1 = lonlat_to_tile(west, north, zoom_level)
    x1, y0 = lonlat_to_tile(east, south, zoom_level)
    if x1 < x0: x0, x1 = x1, x0
    if y1 < y0: y0, y1 = y1, y0
    out.mkdir(parents=True, exist_ok=True)
    template = TEMPLATES[source]
    total = (x1-x0+1)*(y0-y1+1)
    done = 0
    for y in range(y1, y0+1):
        for x in range(x0, x1+1):
            done += 1
            path = out / f"{source}_{zoom_level}_{x}_{y}.png"
            if path.exists():
                print(f"[{done}/{total}] exists {path.name}")
                continue
            url = template.format(z=zoom_level, x=x, y=y)
            print(f"[{done}/{total}] {url}")
            req = Request(url, headers={"User-Agent": "JapaneseArchipelago-data-tools/2.1"})
            with urlopen(req, timeout=45) as resp:
                data = resp.read()
            path.write_bytes(data)
            time.sleep(delay)


def cmd_download(args):
    bbox = tuple(map(float, args.bbox.split(",")))
    if len(bbox) != 4:
        raise SystemExit("bbox must be west,south,east,north")
    download_tiles(args.source, args.zoom, bbox, args.out, args.delay)


def cmd_build(args):
    files = tile_files(args.tiles, args.source, args.zoom)
    mosaic, bounds = mosaic_tiles(files)
    if args.preview:
        p = Path(args.preview)
        normalized = mosaic.copy()
        lo, hi = np.percentile(normalized, 2), np.percentile(normalized, 98)
        preview = np.clip((normalized - lo) / max(1e-6, hi-lo), 0, 1)
        preview = np.nan_to_num(preview, nan=0.0, posinf=1.0, neginf=0.0)
        Image.fromarray((preview * 255).astype(np.uint8), mode="L").save(p)
    filled = fill_nan(mosaic)
    x0, x1, y0, y1 = bounds
    source_cell = gsi_mosaic_cell_size_m(args.zoom, y0)
    out = resample_metric(filled, source_cell, args.cell)
    # Local ENU frame for prototype datasets. X/Z origin at the north-west corner.
    lon_w, _ = tile_to_lonlat(x0 * 256, y0 * 256, args.zoom)
    _, lat_n = tile_to_lonlat(x0 * 256, y0 * 256, args.zoom)
    west_m = 0.0
    south_m = 0.0
    write_jpdm(Path(args.output), out, args.cell, west_m, south_m, args.source, args.zoom, bounds,
               Path(args.metadata) if args.metadata else None)
    print(f"JPDM1: {args.output}")
    print(f"grid: {out.shape[1]} x {out.shape[0]} @ {args.cell:g} m")
    print(f"elevation: {float(np.min(out)):.2f} .. {float(np.max(out)):.2f} m")
    print(f"source tiles: {bounds}")
    print(f"northwest lon/lat (tile corner): {lon_w:.6f}, {lat_n:.6f}")


def main():
    p = argparse.ArgumentParser(description="Japanese Archipelago GSI DEM tooling")
    sp = p.add_subparsers(dest="cmd", required=True)
    d = sp.add_parser("download", help="download GSI XYZ DEM tiles (developer machine only)")
    d.add_argument("--source", choices=sorted(TEMPLATES), default="dem5a")
    d.add_argument("--zoom", type=int, required=True)
    d.add_argument("--bbox", required=True, help="west,south,east,north in degrees")
    d.add_argument("--out", type=Path, default=Path("build/jpdata/gsi_tiles"))
    d.add_argument("--delay", type=float, default=0.20)
    d.set_defaults(func=cmd_download)

    b = sp.add_parser("build", help="local GSI PNG tiles -> JPDM1")
    b.add_argument("--tiles", type=Path, required=True)
    b.add_argument("--source", choices=sorted(TEMPLATES), required=True)
    b.add_argument("--zoom", type=int, required=True)
    b.add_argument("--cell", type=float, default=150.0)
    b.add_argument("--output", type=Path, required=True)
    b.add_argument("--metadata", type=Path)
    b.add_argument("--preview", type=Path)
    b.set_defaults(func=cmd_build)

    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
