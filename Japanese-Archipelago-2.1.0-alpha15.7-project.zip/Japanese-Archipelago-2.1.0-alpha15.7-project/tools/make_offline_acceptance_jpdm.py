#!/usr/bin/env python3
from __future__ import annotations
import gzip, json, math, struct
from pathlib import Path
import numpy as np

ROOT = Path('input/jpdata/japan')
CELL=50.0
CHUNK=256
N=9
SPAN=CELL*CHUNK
ORIGIN_X=-(N//2)*SPAN
ORIGIN_Z=-(N//2)*SPAN
MAGIC=b'JPDM1\0'
HEADER=struct.Struct('<6sBBIIffff')

def write(name, west, south, h):
    gy,gx=np.gradient(h,CELL,CELL,edge_order=1)
    slope=np.degrees(np.arctan(np.hypot(gx,gy))).astype(np.float32)
    gyy,_=np.gradient(gy,CELL,CELL,edge_order=1)
    _,gxx=np.gradient(gx,CELL,CELL,edge_order=1)
    curv=(gxx+gyy).astype(np.float32)
    hh=np.clip(np.rint(h*4),-32768,32767).astype('<i2')
    ss=np.clip(np.rint(slope*100),0,32767).astype('<i2')
    cc=np.clip(np.rint(curv*1000),-32768,32767).astype('<i2')
    header=HEADER.pack(MAGIC,1,7,h.shape[1],h.shape[0],CELL,float(west),float(south),-32768.0)
    out=ROOT/name
    with gzip.open(out,'wb',6) as f:
        f.write(header); f.write(hh.tobytes()); f.write(ss.tobytes()); f.write(cc.tobytes())
    return out

ROOT.mkdir(parents=True,exist_ok=True)
# 9x9 grid around spawn, 115.2 km across. Synthetic acceptance terrain only; it must never be mistaken for GSI data.
# Includes a Fuji-like cone at the origin, surrounding alpine ranges, basins, and coastal lowlands.
for iz in range(N):
    for ix in range(N):
        xs=ORIGIN_X + ix*SPAN + np.arange(CHUNK)*CELL
        zs=ORIGIN_Z + iz*SPAN + np.arange(CHUNK)*CELL
        X,Z=np.meshgrid(xs,zs)
        # broad Japanese-style mountainous corridor
        h=40.0
        h += 650*np.exp(-((X/26000)**2 + (Z/36000)**2))
        h += 420*np.exp(-(((X+26000)/18000)**2 + ((Z-12000)/26000)**2))
        h += 520*np.exp(-(((X-30000)/19000)**2 + ((Z+18000)/24000)**2))
        # Fuji-like volcanic cone, ~3776 m peak, broad foot
        r=np.hypot(X,Z)
        fuji=3736*np.maximum(0,1-r/12000)**2.4
        h += fuji
        # east/west ridges
        h += 170*np.sin(X/4800.0)*np.exp(-(Z/26000)**2)
        h += 120*np.cos(Z/5200.0)*np.exp(-(X/35000)**2)
        # coastal taper into sea around edges
        edge=np.maximum(np.abs(X),np.abs(Z))
        taper=np.clip((60000-edge)/12000,0,1)
        h*=taper
        h=np.clip(h,0,3776).astype(np.float32)
        write(f'test_region_0_{ix}_{iz}.jpdm.gz', ORIGIN_X+ix*SPAN, ORIGIN_Z+iz*SPAN, h)

manifest={
 'format':'JapanJPDMManifest-v1','cell_m':CELL,'chunk_cells':CHUNK,
 'grid_origin_x_m':ORIGIN_X,'grid_origin_z_m':ORIGIN_Z,
 'world_origin_x_m':0.0,'world_origin_z_m':0.0,
 'target_crs':'OFFLINE-ACCEPTANCE-SYNTHETIC','land_mask':'synthetic acceptance dataset',
 'input':'synthetic analytic terrain; not GSI DEM','detail_input':None,'detail_zones':None,
 'tiles':[
   {'ix':ix,'iz':iz,'resource':f'japan/test_region_0_{ix}_{iz}.jpdm.gz'}
   for iz in range(N) for ix in range(N)
 ],
 'stats':{'tiles':N*N,'finite_cells':N*N*CHUNK*CHUNK,'min_m':0.0,'max_m':3776.0},
 'acceptance':'OFFLINE SYNTHETIC ONLY — verifies JPDM manifest loading and non-flat terrain path.'
}
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(ROOT/'test_region_acceptance.json').write_text(json.dumps({
 'format':'JapanRealTestRegionAcceptance-v1','mode':'offline_synthetic_acceptance',
 'center':{'lon':138.55,'lat':35.00},'target_cell_m':CELL,'world_origin_m':{'x':0.0,'z':0.0},
 'runtime_preset':'japanese_archipelago:japan_real',
 'warning':'This dataset is analytic and is NOT real GSI elevation data. Use it only to validate that the runtime no longer falls back to a flat Y=63 terrain.'
},indent=2),encoding='utf-8')
print(f'wrote {N*N} synthetic acceptance JPDM tiles to {ROOT}')
