#!/usr/bin/env python3
"""Inspect a JPDM1 gzip file without Minecraft or network access."""
from __future__ import annotations
import argparse, gzip, struct
from pathlib import Path

HEADER = struct.Struct('<6sBBIIffff')
MAGIC = b'JPDM1\0'

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument('file', type=Path)
    args = p.parse_args()
    with gzip.open(args.file, 'rb') as f:
        raw = f.read(HEADER.size)
    magic, ver, flags, w, h, cell, west, south, nodata = HEADER.unpack(raw)
    if magic != MAGIC:
        raise SystemExit('Not a JPDM1 file')
    print({
        'version': ver, 'flags': flags, 'width': w, 'height': h,
        'cell_m': cell, 'west_m': west, 'south_m': south, 'nodata': nodata,
    })
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
