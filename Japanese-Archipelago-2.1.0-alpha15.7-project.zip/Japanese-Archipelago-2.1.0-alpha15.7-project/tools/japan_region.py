#!/usr/bin/env python3
"""Plan efficient GSI DEM coverage for an irregular Japan land mask.

v3 strategy:
  - land tiles: tiles intersecting the exact land mask;
  - coastal ring: optional one-tile source-resolution ring around land tiles;
  - no kilometer-scale ocean buffer for source DEM by default;
  - reports land/coastal/total tiles and 50 m game-grid estimates.

The planning geometry is never used as the Minecraft land mask. Neighbor-country
land that happens to share a source tile is clipped later by the Japan mask.
"""
from __future__ import annotations

import argparse, json, math
from pathlib import Path
from typing import Iterable

from shapely.geometry import box, mapping, shape
from shapely.ops import unary_union

TEMPLATES = {
    "dem1a": (17, "https://cyberjapandata.gsi.go.jp/xyz/dem1a_png/{z}/{x}/{y}.png"),
    "dem5a": (15, "https://cyberjapandata.gsi.go.jp/xyz/dem5a_png/{z}/{x}/{y}.png"),
    "dem5b": (15, "https://cyberjapandata.gsi.go.jp/xyz/dem5b_png/{z}/{x}/{y}.png"),
    "dem5c": (15, "https://cyberjapandata.gsi.go.jp/xyz/dem5c_png/{z}/{x}/{y}.png"),
    "dem10b": (14, "https://cyberjapandata.gsi.go.jp/xyz/dem_png/{z}/{x}/{y}.png"),
}


def load_geom(path: Path):
    obj = json.loads(path.read_text(encoding="utf-8"))
    if obj.get("type") == "FeatureCollection":
        return unary_union([shape(f["geometry"]) for f in obj.get("features", []) if f.get("geometry")])
    return shape(obj.get("geometry", obj))


def lonlat_to_tile(lon: float, lat: float, z: int):
    n = 2 ** z
    lat = max(-85.05112878, min(85.05112878, lat))
    x = int((lon + 180.0) / 360.0 * n)
    r = math.radians(lat)
    y = int((1.0 - math.asinh(math.tan(r)) / math.pi) / 2.0 * n)
    return x, y


def tile_bounds(x: int, y: int, z: int):
    n = 2 ** z
    west = x / n * 360.0 - 180.0
    east = (x + 1) / n * 360.0 - 180.0
    north = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
    south = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * (y + 1) / n))))
    return box(west, south, east, north)


def iter_bbox_tiles(geom, z: int):
    minx, miny, maxx, maxy = geom.bounds
    xa, yn = lonlat_to_tile(minx, maxy, z)
    xb, ys = lonlat_to_tile(maxx, miny, z)
    xlo, xhi = sorted((xa, xb))
    ylo, yhi = sorted((yn, ys))
    for y in range(ylo, yhi + 1):
        for x in range(xlo, xhi + 1):
            yield x, y


def select_land_tiles(land, z: int):
    selected = set()
    for x, y in iter_bbox_tiles(land, z):
        if land.intersects(tile_bounds(x, y, z)):
            selected.add((x, y))
    return selected


def add_tile_ring(tiles, radius: int):
    if radius <= 0:
        return set(tiles)
    out = set(tiles)
    for x, y in tiles:
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                if max(abs(dx), abs(dy)) <= radius:
                    out.add((x + dx, y + dy))
    return out


def metric_area_km2(geom):
    from pyproj import CRS, Transformer
    from shapely.ops import transform
    lon0, lat0 = geom.centroid.x, geom.centroid.y
    crs = CRS.from_proj4(
        f"+proj=laea +lat_0={lat0} +lon_0={lon0} +datum=WGS84 +units=m +no_defs"
    )
    fwd = Transformer.from_crs("EPSG:4326", crs, always_xy=True).transform
    return transform(fwd, geom).area / 1e6


def main():
    p = argparse.ArgumentParser(description="Plan irregular GSI DEM coverage for Japan")
    p.add_argument("land_mask", type=Path)
    p.add_argument("--source", choices=sorted(TEMPLATES), default="dem10b")
    p.add_argument("--coverage", choices=["land", "land+coast"], default="land+coast")
    p.add_argument("--coast-ring-tiles", type=int, default=1,
                   help="source-tile Chebyshev ring around intersecting land tiles")
    p.add_argument("--game-cell-m", type=float, default=50.0)
    p.add_argument("--out", type=Path, default=Path("input/jpdata/japan/japan_tile_plan.json"))
    p.add_argument("--geojson-out", type=Path, default=Path("input/jpdata/japan/japan_planning_tiles.geojson"))
    a = p.parse_args()

    land = load_geom(a.land_mask).buffer(0)
    if land.is_empty:
        raise SystemExit("Land mask is empty")

    z, template = TEMPLATES[a.source]
    land_tiles = select_land_tiles(land, z)
    if a.coverage == "land+coast":
        selected = add_tile_ring(land_tiles, a.coast_ring_tiles)
    else:
        selected = set(land_tiles)
    coastal_only = selected - land_tiles

    tiles = []
    features = []
    for x, y in sorted(selected, key=lambda q: (q[1], q[0])):
        tile = {
            "z": z,
            "x": x,
            "y": y,
            "zone": "land" if (x, y) in land_tiles else "coast",
            "url": template.format(z=z, x=x, y=y),
        }
        tiles.append(tile)
        features.append({
            "type": "Feature",
            "properties": tile,
            "geometry": mapping(tile_bounds(x, y, z)),
        })

    area_land = metric_area_km2(land)
    land_cells = max(1, int(round((area_land * 1e6) / (a.game_cell_m ** 2))))

    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.geojson_out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps({
        "format": "JapanTileManifest-v5",
        "source": a.source,
        "zoom": z,
        "coverage": a.coverage,
        "coast_ring_tiles": a.coast_ring_tiles if a.coverage == "land+coast" else 0,
        "game_cell_m": a.game_cell_m,
        "estimated_land_area_km2": area_land,
        "estimated_land_cells_50m": land_cells,
        "land_tile_count": len(land_tiles),
        "coastal_only_tile_count": len(coastal_only),
        "tile_count": len(selected),
        "boundary_source": str(a.land_mask),
        "tiles": tiles,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    a.geojson_out.write_text(json.dumps({
        "type": "FeatureCollection",
        "features": features,
    }, ensure_ascii=False), encoding="utf-8")

    print(f"boundary: {a.land_mask}")
    print(f"source: {a.source} / z={z}")
    print(f"coverage: {a.coverage}")
    if a.coverage == "land+coast":
        print(f"coast tile ring: {a.coast_ring_tiles}")
    print(f"game grid: {a.game_cell_m:g} m")
    print(f"estimated land area: {area_land:,.1f} km2")
    print(f"estimated land cells: {land_cells:,}")
    print(f"land tiles: {len(land_tiles):,}")
    print(f"coastal-only tiles: {len(coastal_only):,}")
    print(f"tiles selected: {len(selected):,}")
    print(f"manifest: {a.out}")
    print(f"tile footprint: {a.geojson_out}")


if __name__ == "__main__":
    main()
