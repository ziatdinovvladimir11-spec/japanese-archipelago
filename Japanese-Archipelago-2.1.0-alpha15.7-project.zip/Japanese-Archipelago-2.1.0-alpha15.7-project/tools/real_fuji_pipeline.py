#!/usr/bin/env python3
"""Prepare a Fuji-region GSI DEM mosaic for Japanese Archipelago.

Developer-time only: downloads official GSI XYZ DEM tiles to local disk, then
builds a continuous metric JPDM dataset. Minecraft runtime never uses HTTP.

Examples:
  python tools/real_fuji_pipeline.py all --source dem1a --radius 12
  python tools/real_fuji_pipeline.py build --source dem1a --radius 12

The default center is Mt. Fuji. Radius is in XYZ tiles around the center tile.
For the real Fuji test we use DEM1A at z=15 (about 4-5 m pixels near Fuji),
which is still much finer than our 50 m JPDM target grid while keeping the
download practical. Existing valid tiles are reused.
"""
from __future__ import annotations

import argparse
import gzip
import json
import math
import struct
import time
from pathlib import Path

import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter, zoom
from gsi_download import download_with_retry, validate_png

TEMPLATES = {
    "dem1a": "https://cyberjapandata.gsi.go.jp/xyz/dem1a_png/{z}/{x}/{y}.png",
    "dem5a": "https://cyberjapandata.gsi.go.jp/xyz/dem5a_png/{z}/{x}/{y}.png",
    "dem5b": "https://cyberjapandata.gsi.go.jp/xyz/dem5b_png/{z}/{x}/{y}.png",
    "dem5c": "https://cyberjapandata.gsi.go.jp/xyz/dem5c_png/{z}/{x}/{y}.png",
    "dem10b": "https://cyberjapandata.gsi.go.jp/xyz/dem_png/{z}/{x}/{y}.png",
}
ZOOMS = {"dem1a": 15, "dem5a": 15, "dem5b": 15, "dem5c": 15, "dem10b": 14}
FUJI_LON = 138.7278
FUJI_LAT = 35.3606
JPDM_MAGIC = b"JPDM1\0"
HEADER = struct.Struct("<6sBBII f f f f")


def lonlat_to_tile(lon: float, lat: float, z: int) -> tuple[int, int]:
    n = 2 ** z
    lat = max(-85.05112878, min(85.05112878, lat))
    x = int((lon + 180.0) / 360.0 * n)
    r = math.radians(lat)
    y = int((1.0 - math.asinh(math.tan(r)) / math.pi) / 2.0 * n)
    return x, y


def tile_to_lonlat(px: int, py: int, z: int) -> tuple[float, float]:
    npx = 256 * (2 ** z)
    lon = px / npx * 360.0 - 180.0
    t = math.pi * (1.0 - 2.0 * py / npx)
    lat = math.degrees(math.atan(math.sinh(t)))
    return lon, lat


def decode_gsi_png(path: Path) -> np.ndarray:
    rgb = np.asarray(Image.open(path).convert("RGB"), dtype=np.uint32)
    x = (rgb[:, :, 0] << 16) + (rgb[:, :, 1] << 8) + rgb[:, :, 2]
    invalid = (rgb[:, :, 0] == 128) & (rgb[:, :, 1] == 0) & (rgb[:, :, 2] == 0)
    h = x.astype(np.float64) * 0.01
    neg = x > (1 << 23)
    h[neg] = (x[neg].astype(np.int64) - (1 << 24)) * 0.01
    h[x == (1 << 23)] = np.nan
    h[invalid] = np.nan
    return h.astype(np.float32)


def cell_size_m(z: int, y_tile: int) -> float:
    _, lat = tile_to_lonlat(0, y_tile * 256 + 128, z)
    world_m = 40075016.68557849
    return world_m * math.cos(math.radians(lat)) / (2 ** z) / 256.0


def tile_path(out: Path, source: str, z: int, x: int, y: int) -> Path:
    return out / f"{source}_{z}_{x}_{y}.png"


def center_tile(source: str) -> tuple[int, int, int]:
    z = ZOOMS[source]
    x, y = lonlat_to_tile(FUJI_LON, FUJI_LAT, z)
    return x, y, z


def download_region(source: str, radius: int, out: Path, delay: float) -> None:
    x, y, z = center_tile(source)
    out.mkdir(parents=True, exist_ok=True)
    total = (radius * 2 + 1) ** 2
    done = 0
    failures: list[tuple[int, int]] = []
    for ty in range(y - radius, y + radius + 1):
        for tx in range(x - radius, x + radius + 1):
            done += 1
            dst = tile_path(out, source, z, tx, ty)
            if dst.exists() and validate_png(dst):
                print(f"[{done}/{total}] exists {dst.name}")
                continue
            if dst.exists():
                print(f"[{done}/{total}] invalid cache {dst.name}; re-downloading")
                dst.unlink(missing_ok=True)
            url = TEMPLATES[source].format(z=z, x=tx, y=ty)
            print(f"[{done}/{total}] GET {url}")
            ok, attempts, error = download_with_retry(url, dst, attempts=5, timeout=60.0)
            if ok:
                print(f"  OK after {attempts} attempt(s)")
            else:
                failures.append((tx, ty))
                print(f"  WARN after {attempts} attempts: {error}")
            time.sleep(delay)
    # Final audit: do not build an incomplete mosaic unless explicitly requested.
    audit_missing = []
    for ty in range(y - radius, y + radius + 1):
        for tx in range(x - radius, x + radius + 1):
            p = tile_path(out, source, z, tx, ty)
            if not validate_png(p):
                audit_missing.append((tx, ty))
    failures = audit_missing
    print(f"Completed: {total} requested tiles; valid: {total - len(failures)}; failures: {len(failures)}")
    if failures:
        print("Missing/invalid tiles:", ", ".join(f"{tx},{ty}" for tx, ty in failures[:20]))
        print("Rerun the same command later to retry only missing/invalid tiles.")


def find_tiles(folder: Path, source: str, z: int) -> dict[tuple[int, int], Path]:
    prefix = f"{source}_{z}_"
    result: dict[tuple[int, int], Path] = {}
    for p in folder.glob(f"{prefix}*_*.png"):
        try:
            xs, ys = p.stem[len(prefix):].split("_", 1)
            result[(int(xs), int(ys))] = p
        except ValueError:
            pass
    return result


def mosaic(files: dict[tuple[int, int], Path], allow_missing: bool) -> tuple[np.ndarray, tuple[int, int, int, int]]:
    if not files:
        raise RuntimeError("No GSI tiles found")
    xs = [k[0] for k in files]; ys = [k[1] for k in files]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    ref = decode_gsi_png(next(iter(files.values())))
    th, tw = ref.shape
    out = np.full(((y1-y0+1)*th, (x1-x0+1)*tw), np.nan, dtype=np.float32)
    missing = 0
    for ty in range(y0, y1 + 1):
        for tx in range(x0, x1 + 1):
            p = files.get((tx, ty))
            if p is None:
                missing += 1
                continue
            tile = decode_gsi_png(p)
            if tile.shape != (th, tw):
                raise RuntimeError(f"Tile {p} has shape {tile.shape}, expected {(th, tw)}")
            out[(ty-y0)*th:(ty-y0+1)*th, (tx-x0)*tw:(tx-x0+1)*tw] = tile
    if missing and not allow_missing:
        raise RuntimeError(f"Mosaic has {missing} missing tiles; rerun download or use --allow-missing")
    return out, (x0, x1, y0, y1)


def fill_nan(arr: np.ndarray) -> np.ndarray:
    out = arr.copy()
    for _ in range(24):
        mask = np.isnan(out)
        if not mask.any():
            return out
        acc = np.zeros_like(out, dtype=np.float64)
        cnt = np.zeros_like(out, dtype=np.float64)
        for dy, dx in ((-1,0),(1,0),(0,-1),(0,1)):
            shifted = np.roll(out, (dy, dx), axis=(0,1))
            valid = ~np.isnan(shifted)
            acc += np.where(valid, shifted, 0.0)
            cnt += valid
        repl = mask & (cnt > 0)
        out[repl] = (acc[repl] / cnt[repl]).astype(np.float32)
    if np.isnan(out).any():
        out[np.isnan(out)] = float(np.nanmedian(out))
    return out


def derivatives(height: np.ndarray, cell_m: float) -> tuple[np.ndarray, np.ndarray]:
    gy, gx = np.gradient(height, cell_m, cell_m, edge_order=1)
    slope = np.degrees(np.arctan(np.hypot(gx, gy))).astype(np.float32)
    gyy, _ = np.gradient(gy, cell_m, cell_m, edge_order=1)
    _, gxx = np.gradient(gx, cell_m, cell_m, edge_order=1)
    curvature = (gxx + gyy).astype(np.float32)
    return slope, curvature


def resample(arr: np.ndarray, src_m: float, dst_m: float) -> np.ndarray:
    factor = src_m / dst_m
    out_h = max(2, int(round(arr.shape[0] * factor)))
    out_w = max(2, int(round(arr.shape[1] * factor)))
    return zoom(arr, (out_h / arr.shape[0], out_w / arr.shape[1]), order=1,
                mode="nearest", prefilter=False, grid_mode=True).astype(np.float32)


def write_jpdm(out_path: Path, height: np.ndarray, cell_m: float, metadata: dict) -> None:
    slope, curv = derivatives(height, cell_m)
    h = np.clip(np.rint(height * 4.0), -32767, 32767).astype("<i2")
    s = np.clip(np.rint(slope * 100.0), 0, 32767).astype("<i2")
    c = np.clip(np.rint(curv * 1000.0), -32767, 32767).astype("<i2")
    flags = 1 | 2 | 4
    header = HEADER.pack(JPDM_MAGIC, 1, flags, h.shape[1], h.shape[0], float(cell_m), 0.0, 0.0, -32768.0)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(out_path, "wb", compresslevel=6) as f:
        f.write(header); f.write(h.tobytes()); f.write(s.tobytes()); f.write(c.tobytes())
    out_path.with_suffix(out_path.suffix + ".json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")


def build_region(source: str, radius: int, tiles_dir: Path, out_dir: Path, target_cell: float, allow_missing: bool) -> None:
    z = ZOOMS[source]
    files = find_tiles(tiles_dir, source, z)
    cx, cy, cz = center_tile(source)
    expected = {(tx, ty) for ty in range(cy-radius, cy+radius+1) for tx in range(cx-radius, cx+radius+1)}
    missing_expected = sorted(expected - set(files))
    if missing_expected and not allow_missing:
        raise RuntimeError(f"Mosaic has {len(missing_expected)} missing expected tiles; rerun download")
    mosaic_arr, bounds = mosaic(files, allow_missing=allow_missing)
    raw = mosaic_arr.copy()
    filled = fill_nan(mosaic_arr)
    # Very light low-pass only for tile-boundary noise; preserve terrain shapes.
    smoothed = gaussian_filter(filled, sigma=0.35)
    src_m = cell_size_m(z, bounds[2])
    sampled = resample(smoothed, src_m, target_cell)
    out = out_dir / f"fuji_{source}_r{radius}_{int(target_cell)}m.jpdm.gz"
    meta = {
        "format": "JPDM1", "version": 1, "source": source, "zoom": z,
        "fuji_center": {"lon": FUJI_LON, "lat": FUJI_LAT}, "radius_tiles": radius,
        "tile_bounds": {"x0": bounds[0], "x1": bounds[1], "y0": bounds[2], "y1": bounds[3]},
        "source_cell_m_approx": src_m, "target_cell_m": target_cell,
        "grid": {"width": int(sampled.shape[1]), "height": int(sampled.shape[0])},
        "raw_min_m": float(np.nanmin(raw)), "raw_max_m": float(np.nanmax(raw)),
        "processed_min_m": float(np.min(sampled)), "processed_max_m": float(np.max(sampled)),
        "invalid_raw_cells": int(np.isnan(raw).sum()),
        "processing": ["GSI XYZ PNG", "RGB elevation decode", "nan fill", "light Gaussian smoothing sigma=0.35", "bilinear resampling", "slope and curvature derivation"],
        "distribution": "Do not redistribute raw GSI data. Review current GSI terms for derived datasets.",
    }
    write_jpdm(out, sampled, target_cell, meta)
    preview = np.clip((sampled - np.percentile(sampled, 2)) /
                      max(1e-6, np.percentile(sampled, 98) - np.percentile(sampled, 2)), 0, 1)
    Image.fromarray((preview * 255).astype(np.uint8), mode="L").save(out_dir / (out.stem.replace('.jpdm','') + "_preview.png"))
    print(f"JPDM written: {out}")
    print(f"grid: {sampled.shape[1]} x {sampled.shape[0]} @ {target_cell:g}m")
    print(f"elevation: {sampled.min():.2f} .. {sampled.max():.2f} m")


def main() -> None:
    p = argparse.ArgumentParser(description="Fuji region GSI DEM mosaic/preprocessor")
    p.add_argument("action", choices=["download", "build", "all"])
    p.add_argument("--source", choices=sorted(TEMPLATES), default="dem5a")
    p.add_argument("--radius", type=int, default=8)
    p.add_argument("--tiles", type=Path, default=Path("input/jpdata/fuji/tiles"))
    p.add_argument("--out", type=Path, default=Path("input/jpdata/fuji"))
    p.add_argument("--cell", type=float, default=50.0, help="target metric cell size")
    p.add_argument("--delay", type=float, default=0.20)
    p.add_argument("--allow-missing", action="store_true")
    a = p.parse_args()
    if a.action in ("download", "all"):
        download_region(a.source, a.radius, a.tiles, a.delay)
    if a.action in ("build", "all"):
        build_region(a.source, a.radius, a.tiles, a.out, a.cell, a.allow_missing)

if __name__ == "__main__":
    main()
