@echo off
setlocal
cd /d "%~dp0"
call gradlew.bat build
if errorlevel 1 (
  echo.
  echo BUILD FAILED.
  pause
  exit /b 1
)
echo.
echo BUILD SUCCESSFUL. The mod JAR is in build\libs\
pause
